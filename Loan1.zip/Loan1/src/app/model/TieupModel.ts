export class TieupModel
{
    id: number = 0
      createdDate: Date = new Date()
      modifiedDate: Date = new Date()
      isDeleted: boolean = false
      createdBy: number = 0
      modifiedBy: number = 0
      message: string =''
      loanRequestId: number = 0
      tieUpCompanyId: number = 0
      tieupLetterDate: Date = new Date()
      maximumLoanAmount: number = 0
    constructor()
    {

    }
}