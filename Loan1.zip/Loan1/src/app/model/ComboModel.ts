export class ComboModel
{
    value:string =''
    text:string =''
    constructor()
    {

    }
}