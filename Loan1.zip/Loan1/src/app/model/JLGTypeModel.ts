export class JLGTypeModel{
    id: number = 0
    createdDate: Date = new Date()
    modifiedDate: Date = new Date()
    isDeleted: boolean = false
    createdBy: number = 0
    modifiedBy: number = 0
    message: string = ''
    loanRequestId: number = 0
    memberId: number = 0
    resolutionNumber: number = 0
    resolutionDate: Date = new Date()
    memberSavingsAmount: number = 0
    govtRFSubsidyAmount: number = 0
    loanOutstanding: number = 0
    membersODLoanAmount: number = 0
    interestIncome: number = 0
    jlgCashBalance: number = 0
    balanceAmount: number = 0
constructor()
{

}
}