export class CropDetails{
category:string="";
crop:string="";
cropId:number=0;
surveyNo:string="";
acre:number=0;
cultivationAcre:number=0;
    constructor()
    {

    }
}