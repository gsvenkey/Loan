 import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {ComboModel} from 'src/app/model/ComboModel';
import {LoanRequestModel} from 'src/app/model/LoanRequestModel';


@Injectable({
  providedIn: 'root'
})
export class APICall {
  constructor(private httpClient: HttpClient) {              
  }
  baseUrl: string = "https://localhost:44367/api/";
 
  BindMember(pacsId:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'MemberMaster/SelectMember/'+pacsId);
  }
  BindLoanType() {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'LoanTypeMaster/SelectLoanType');
  }
  BindCropCategoryList() {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'CropCategory/SelectCropCategory');
  }
  BindCropListByCategory(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'CropMaster/SelectCrop/'+id);
  }
  GetMemberInfo(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'MemberMaster/GetMemberInfo/'+id);
  }
  GetSurveyDetails(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'VAOCertificate/GetServeyDeta ils/'+id);
  }
SaveLoanRequest(model:LoanRequestModel)
{
  let headers = new HttpHeaders();
  headers.append('Content-Type', 'multipart/form-data');
  headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
  headers.append('Accept', 'application/json, text/plain, */*');
  const httpOptions = { headers: headers };     
   return this.httpClient.post<boolean>(this.baseUrl+'LoanRequest',model,httpOptions);
}
}
