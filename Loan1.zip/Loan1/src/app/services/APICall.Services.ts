 import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {ComboModel} from 'src/app/model/ComboModel';
import {LoanRequestModel} from 'src/app/model/LoanRequestModel';
import {LoanListModel} from 'src/app/model/LoanListModel';


@Injectable({
  providedIn: 'root'
})
export class APICall {
  constructor(private httpClient: HttpClient) {              
  }
  baseUrl: string = "https://localhost:44367/api/";
 
  BindMember(pacsId:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'MemberMaster/SelectMember/'+pacsId);
  }
  BindLoanType() {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'LoanTypeMaster/SelectLoanType');
  }
  BindLoanList(pacsId:number,fyearId:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<LoanListModel[]>(this.baseUrl+'LoanRequest/GetList/' + pacsId +"/"+fyearId);
  }
  GetLoanDetails(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<LoanRequestModel>(this.baseUrl+'LoanRequest/GetById/' + id);
  }
  DeleteLoanRequest(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.delete<boolean>(this.baseUrl+'LoanRequest/' + id);
  }
  UpdateLoanRequest(id:number,model:LoanRequestModel) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.put<boolean>(this.baseUrl+'LoanRequest/' + id,model);
  }
  BindCropCategoryList() {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'CropCategory/SelectCropCategory');
  }
  BindCropListByCategory(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'CropMaster/SelectCrop/'+id);
  }
  GetMemberInfo(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'MemberMaster/GetMemberInfo/'+id);
  }
  GetSurveyDetails(id:number) {   
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };     
     return this.httpClient.get<ComboModel[]>(this.baseUrl+'VAOCertificate/GetServeyDeta ils/'+id);
  }
SaveLoanRequest(model:LoanRequestModel)
{
  let headers = new HttpHeaders();
  headers.append('Content-Type', 'multipart/form-data');
  headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
  headers.append('Accept', 'application/json, text/plain, */*');
  const httpOptions = { headers: headers };     
   return this.httpClient.post<boolean>(this.baseUrl+'LoanRequest',model,httpOptions);
}
}
