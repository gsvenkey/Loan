import { Injectable } from '@angular/core';
import { Config } from 'protractor';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConfigServicesService {
  config: any;

  constructor(private http: HttpClient) {}

  loadConfig() {
    return this.http
      .get<Config>('./config.json')
      .toPromise()
      .then(config => {
        this.config = config;
      });
  }

} 
 