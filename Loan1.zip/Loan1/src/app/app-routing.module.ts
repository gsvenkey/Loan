import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { LoanSanctionComponent } from './components/loan-sanction/loan-sanction.component';
import { LoanIssueComponent } from './components/loan-issue/loan-issue.component';
import { LoanReciptComponent } from './components/loan-recipt/loan-recipt.component';
import { VaoCertificateEntryComponent } from './components/vao-certificate-entry/vao-certificate-entry.component';
const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'administration', component: AdministrationComponent },
  { path: 'loan-sanction', component: LoanSanctionComponent },
  { path: 'loan-issue', component: LoanIssueComponent },
  { path: 'loan-receipt', component: LoanReciptComponent },
  { path: 'vao-certificate-entry', component: VaoCertificateEntryComponent }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent = [HomeComponent]
