import { Component, OnInit ,Output,EventEmitter} from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import {ComboModel} from 'src/app/model/ComboModel';
declare var $:any;

@Component({
  selector: 'app-member-details',
  templateUrl: './member-details.component.html',
  styleUrls: ['./member-details.component.css']
})
export class MemberDetailsComponent implements OnInit {
  loanTypList:ComboModel[]=[];
memberList:ComboModel[]=[];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  mobile: string = "";
photoUrl:string="";
@Output() getMemberChange = new EventEmitter<number>();
@Output() getLoanTypeChange = new EventEmitter<string>();
@Output() getLoanTypeIdChange = new EventEmitter<number>();
@Output() getAdangalChange = new EventEmitter<boolean>();
@Output() getPasaliYear = new EventEmitter<number>();


loanType:string='';
loanTypeId:number=0;
RequestDate:string=new Date().toDateString();
Adangal:boolean=false;
Pasali:number=0;
  constructor(private _apiService:APICall) { }

  ngOnInit() {
    this.GetMemberList();
    this.GetLoanTypes();
  }
  PasaliKeyup()
  {
    this.getPasaliYear.emit(this.Pasali)
    let month:number=new Date().getMonth();
    let year:number=new Date().getFullYear();
    if(month<=6)
    {
      this.Pasali=Number(year)-Number(591);
    }
    else
    {
      this.Pasali=Number(Number(year)-Number(591)) + Number(1);
    }
  }
  GetLoanTypes()
  {
    this._apiService.BindLoanType().subscribe((result:ComboModel[]) => {
      this.loanTypList=result;
      console.log(this.loanTypList);
    });
  }
  GetMemberList()
  {
    this._apiService.BindMember(1).subscribe((result:ComboModel[]) => {
      this.memberList=result;
      console.log(this.memberList);
    });
  }
  selected(e:any) {
    let id:number = e.target.value;
    this.getMemberChange.emit(id)
    this._apiService.GetMemberInfo(id).subscribe((result:any) => {
      this.memberName = result.name;
      this.memberAdd1 = result.address1;
      this.memberAdd2 = result.address2;
      this.memberAdd3 = result.address3;
      this.mobile=result.mobileNumber;
      this.photoUrl = result.photoUrl;
    });
  
  }
  selectedLoan(e:any) {
    this.loanType = e.target.value;
    this.loanTypeId=$(e.target).find('option:selected').data('type');
    this.getLoanTypeChange.emit(this.loanType);
    this.getLoanTypeIdChange.emit(this.loanTypeId);

  }
}
