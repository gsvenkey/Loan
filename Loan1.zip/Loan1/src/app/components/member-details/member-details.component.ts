import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
declare var $: any;

@Component({
  selector: 'app-member-details',
  templateUrl: './member-details.component.html',
  styleUrls: ['./member-details.component.css']
})
export class MemberDetailsComponent implements OnInit {
  loanTypList: ComboModel[] = [];
  memberList: ComboModel[] = [];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  aadhar: string = "";
  mobile: string = "";
  photoUrl: string = "";
  loanType: string = '';
  @Input() loanTypeId: number = 0;
  RequestDate: string = new Date().toDateString();
  @Input() Adangal: boolean = false;
  @Input() Pasali: number = 0;
  @Input() memberId: number = 0;

  @Output() getMemberChange = new EventEmitter<number>();
  @Output() getLoanTypeChange = new EventEmitter<string>();
  @Output() getLoanTypeIdChange = new EventEmitter<number>();
  @Output() getAdangalChange = new EventEmitter<boolean>();
  @Output() getPasaliYear = new EventEmitter<number>();

  constructor(private _apiService: APICall) { }

  ngOnInit() {
    this.GetMemberList();
    this.GetLoanTypes();
    console.log(this.RequestDate);
  }
  PasaliKeyup() {
    this.getPasaliYear.emit(this.Pasali)
    let month: number = new Date().getMonth();
    let year: number = new Date().getFullYear();
    if (month <= 6) {
      //this.Pasali = Number(year) - Number(591);
      console.log(Number(year) - Number(591));
      if(this.Pasali!=Number(year) - Number(591)){
        this.Pasali =0;
        alert('Enter correct pasali year!!!');
      }
    }
    else {
      console.log(Number(Number(year) - Number(591)) + Number(1));
      if(this.Pasali!=Number(Number(year) - Number(591)) + Number(1)){
        this.Pasali =0;
        alert('Enter correct pasali year!!!');
      }
    }
  }
  GetLoanTypes() {
    this._apiService.BindLoanType().subscribe((result: ComboModel[]) => {
      this.loanTypList = result;
      console.log(this.loanTypList);
    });
  }
  GetMemberList() {
    this._apiService.BindMember(1).subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }
  GetJlgMemberList() {
    this._apiService.BindJlgMember(1).subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }
  selected(e: any) {
    let id: number = e.target.value;
    this.getMemberChange.emit(id)
    this._apiService.GetMemberInfo(id).subscribe((result: any) => {
      if(result!=null)
      {
      this.memberName = result.name;
      this.memberAdd1 = result.address1;
      this.memberAdd2 = result.address2;
      this.memberAdd3 = result.address3;
      this.aadhar = result.adhaarNumber;
      this.mobile = result.mobileNumber;
      this.photoUrl = result.photoUrl;
      }
      else
      {
        this.memberName = '';
        this.memberAdd1 = '';
        this.memberAdd2 = '';
        this.memberAdd3 = '';
        this.aadhar = '';
        this.mobile = '';
        this.photoUrl = '';
      }
    });

  }
  selectedLoan(e: any) {
    this.loanType = $(e.target).find('option:selected').data('type');
    this.loanTypeId = e.target.value;
    this.getLoanTypeChange.emit(this.loanType);
    this.getLoanTypeIdChange.emit(this.loanTypeId);
    if (this.loanType == "JLG") {
      this.GetJlgMemberList();
    }else{
      this.GetMemberList();
    }
  }
}
