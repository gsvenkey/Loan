import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-capability-search',
  templateUrl: './capability-search.component.html',
  styleUrls: ['./capability-search.component.css']
})
export class CapabilitySearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    if ( $.fn.DataTable.isDataTable('#tbl_capabilitysearch') ) {
      $('#tbl_capabilitysearch').DataTable().destroy();
    }
    var table = $('#tbl_capabilitysearch').DataTable();
  }
}
