import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CapabilitySearchComponent } from './capability-search.component';

describe('CapabilitySearchComponent', () => {
  let component: CapabilitySearchComponent;
  let fixture: ComponentFixture<CapabilitySearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CapabilitySearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CapabilitySearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
