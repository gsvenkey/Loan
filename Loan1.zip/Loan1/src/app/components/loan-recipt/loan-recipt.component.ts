import { Component, OnInit } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanIssueListModel } from 'src/app/model/LoanIssueListModel'

@Component({
  selector: 'app-loan-recipt',
  templateUrl: './loan-recipt.component.html',
  styleUrls: ['./loan-recipt.component.css']
})
export class LoanReciptComponent implements OnInit {
  memberList: ComboModel[] = [];
  ReceiptDate:string=new Date().toDateString();
  BP:number=0;
  PT:number=0;
  RA:number=0;
  TotalOut:number=0;
  OtherFees:number=0;
  EPF:number=0;
  ARC:number=0;
  NoticeCharge:number=0;
  PenalInterest:number=0;
  Interest:number=0;
  PROF:number=0;
  ROI:number=0;
  PI:number=0;
  NI:number=0;
  PP:number=0;
  IA:number=0;
  IDD:number=0;
  IID:number=0;
  LoanNo:string='0';
  LoanTypeId:string='0';
  IssueNo:string='0';
  MemberId:string='0';
IssueList:LoanIssueListModel[]=[];
loanTypeList:ComboModel[]=[];
  constructor(private _apiService: APICall) { }

  ngOnInit(){
    this.GetMemberList();
    this.GetIssueList();
    this.GetLoanTypes();
  }
  Save()
  {

  }
  Clear()
  {
    
  }
  GetLoanTypes() {
    this._apiService.BindLoanType().subscribe((result: ComboModel[]) => {
      this.loanTypeList = result;
    });
  }
  GetMemberList() {
    this._apiService.BindMember(1).subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }
  GetIssueList() {
    this._apiService.BindLoanIssueList(1,1).subscribe((result: LoanIssueListModel[]) => {
      this.IssueList = result;
      console.log(this.memberList);
    });
  }
  selected(e: any) {
    let id: number = e.target.value;
    this._apiService.GetMemberInfo(id).subscribe((result: any) => {
     
    });
  }
}
