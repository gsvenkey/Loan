import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanReciptComponent } from './loan-recipt.component';

describe('LoanReciptComponent', () => {
  let component: LoanReciptComponent;
  let fixture: ComponentFixture<LoanReciptComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanReciptComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanReciptComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
