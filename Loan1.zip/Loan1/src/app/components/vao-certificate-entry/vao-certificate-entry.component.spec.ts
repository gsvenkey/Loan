import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VaoCertificateEntryComponent } from './vao-certificate-entry.component';

describe('VaoCertificateEntryComponent', () => {
  let component: VaoCertificateEntryComponent;
  let fixture: ComponentFixture<VaoCertificateEntryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VaoCertificateEntryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VaoCertificateEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
