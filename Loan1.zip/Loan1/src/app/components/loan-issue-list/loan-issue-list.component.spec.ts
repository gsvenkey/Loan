import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanIssueListComponent } from './loan-issue-list.component';

describe('LoanIssueListComponent', () => {
  let component: LoanIssueListComponent;
  let fixture: ComponentFixture<LoanIssueListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanIssueListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanIssueListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
