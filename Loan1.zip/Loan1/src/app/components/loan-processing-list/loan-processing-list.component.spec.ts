import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanProcessingListComponent } from './loan-processing-list.component';

describe('LoanProcessingListComponent', () => {
  let component: LoanProcessingListComponent;
  let fixture: ComponentFixture<LoanProcessingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanProcessingListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanProcessingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
