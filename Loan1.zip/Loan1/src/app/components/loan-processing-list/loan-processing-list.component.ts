import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loan-processing-list',
  templateUrl: './loan-processing-list.component.html',
  styleUrls: ['./loan-processing-list.component.css']
})
export class LoanProcessingListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
