import { Component, OnInit , Output, EventEmitter} from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import{LoanSanctionListModel} from 'src/app/model/LoanSanctionListModel'
import{LoanSanctionModel} from 'src/app/model/LoanSanctionModel'
@Component({
  selector: 'app-loan-sanction-list',
  templateUrl: './loan-sanction-list.component.html',
  styleUrls: ['./loan-sanction-list.component.css']
})
export class LoanSanctionListComponent implements OnInit {
list:LoanSanctionListModel[]=[];
@Output() getLoanDetails = new EventEmitter<LoanSanctionModel>();

  constructor(private _apiService:APICall) { }

  ngOnInit() {
    this.GetLoanList();
  }
  GetLoanList()
  {
    this._apiService.BindLoanSanctionList(1,1).subscribe((result:LoanSanctionListModel[]) => {
      this.list=result;
      console.log(this.list);
    });
  }
  Edit(id:number)
  {
    this._apiService.GetLoanSanctionDetails(id).subscribe((result:LoanSanctionModel) => {
 this.getLoanDetails.emit(result);
    });
  }
  Delete(id:number)
  {
    if (confirm('Are you sure want to delete this item?')) {
      this._apiService.DeleteLoanSanctionRequest(id).subscribe((result:boolean) => {
        if(result)
        {
          alert("success");
          this.GetLoanList();
        }
        else
        {
          alert("failure")
        }
      });
     
    } else {
      // Do nothing!
      console.log('Thing was not saved to the database.');
    }
    
  }
}
