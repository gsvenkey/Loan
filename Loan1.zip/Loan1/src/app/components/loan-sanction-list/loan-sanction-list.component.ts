import { Component, OnInit, Output, EventEmitter,Input } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { LoanSanctionListModel } from 'src/app/model/LoanSanctionListModel'
import { LoanSanctionModel } from 'src/app/model/LoanSanctionModel'
@Component({
  selector: 'app-loan-sanction-list',
  templateUrl: './loan-sanction-list.component.html',
  styleUrls: ['./loan-sanction-list.component.css']
})
export class LoanSanctionListComponent implements OnInit {
  @Input() list: LoanSanctionListModel[] = [];
  @Output() getLoanDetails = new EventEmitter<LoanSanctionModel>();

  constructor(private _apiService: APICall) { }

  ngOnInit() {
  }
  GetLoanList() {
    this._apiService.BindLoanSanctionList(1, 1).subscribe((result: LoanSanctionListModel[]) => {
      this.list = result;
    });
  }
  Edit(id: number) {
    this._apiService.GetLoanSanctionDetails(id).subscribe((result: LoanSanctionModel) => {
      this.getLoanDetails.emit(result);
    });
  }
  Delete(id: number) {
    if (confirm('Are you sure want to delete this item?')) {
      this._apiService.DeleteLoanSanctionRequest(id).subscribe((result: boolean) => {
        if (result) {
          alert("success");
          this.GetLoanList();
        }
        else {
          alert("failure")
        }
      });

    } else {
      // Do nothing!
      console.log('Thing was not saved to the database.');
    }

  }
}
