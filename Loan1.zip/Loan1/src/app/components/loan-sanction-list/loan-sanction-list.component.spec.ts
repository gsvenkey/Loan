import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanSanctionListComponent } from './loan-sanction-list.component';

describe('LoanSanctionListComponent', () => {
  let component: LoanSanctionListComponent;
  let fixture: ComponentFixture<LoanSanctionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanSanctionListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanSanctionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
