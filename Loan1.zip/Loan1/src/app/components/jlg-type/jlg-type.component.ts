import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import {ComboModel} from 'src/app/model/ComboModel';
import {JLGTypeModel} from 'src/app/model/JLGTypeModel';
import {JLGLoanMemberModel} from 'src/app/model/JLGLoanMemberModel';



@Component({
  selector: 'app-jlg-type',
  templateUrl: './jlg-type.component.html',
  styleUrls: ['./jlg-type.component.css']
})
export class JlgTypeComponent implements OnInit {
  memberId:number=0;
  memberList:ComboModel[]=[];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  mobile: string = "";
photoUrl:string="";
RD:Date = new Date();
II : number =0;
SA:number =0;
MSA:number =0;
JLGCB:number =0;
LOA:number =0;
SABA:number =0;
ODLA:number=0;
JLGMembers:JLGLoanMemberModel[]=[];
@Output() getModel = new EventEmitter<JLGTypeModel[]>();
@Output() getJLGMember = new EventEmitter<JLGLoanMemberModel[]>();

  constructor(private _apiService:APICall) { }

  ngOnInit(): void {
    this.GetMemberList();
  }
  DeleteRow(id:number)
  {
    this.JLGMembers.forEach((element,index)=>{
      if(element.memberId == id) this.JLGMembers.splice(index,1);
   });
  }

  GetMemberList()
  {
    this._apiService.BindMember(1).subscribe((result:ComboModel[]) => {
      this.memberList=result;
      console.log(this.memberList);
    });
  }
  selected(e:any) {
    let id:number = e.target.value;
    this.memberId=id;
    this._apiService.GetMemberInfo(id).subscribe((result:any) => {
      var arr : JLGLoanMemberModel ={
        name:result.name,
        AadharNo:result.aadharNo,
        mobileNo:result.mobileNumber,
        memberId:id,
        modifiedDate:new Date(),
        modifiedBy:1,
        message:'',
        loanRequestId:1,
        isDeleted:false,
        createdDate:new Date(),
        createdBy:1,
        id:0,
        photoUrl:result.photoUrl
      }
      this.JLGMembers.push(arr);
      this.getJLGMember.emit(this.JLGMembers);
    });
  }

  ModelBinding()
  {
     var model:JLGTypeModel={
       createdBy:1,
       balanceAmount:this.SABA,
       createdDate:new Date(),
       govtRFSubsidyAmount:this.SA,
       id:0,
interestIncome:this.II,
isDeleted:false,
jlgCashBalance:this.JLGCB,
loanOutstanding:this.LOA,
loanRequestId:1,
memberId:this.memberId,
memberSavingsAmount:this.SA,
membersODLoanAmount:this.ODLA,
message:"",
modifiedBy:1,
modifiedDate:new Date(),
resolutionDate:this.RD,
resolutionNumber:0
     }
     var arr : JLGTypeModel[] = [];
arr.push(model);
     this.getModel.emit(arr);
  }
}
