import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import {ComboModel} from 'src/app/model/ComboModel';
import {JewelDetails} from 'src/app/model/JewelDetails';
declare var $:any;

@Component({
  selector: 'app-jewel-type',
  templateUrl: './jewel-type.component.html',
  styleUrls: ['./jewel-type.component.css']
})
export class JewelTypeComponent implements OnInit {
  jewelDetails:JewelDetails[]=[];
  jewelList:ComboModel[]=[];
  jewelitem:string="";
  noofitem:number=0;
totalwt:number=0;
disallowedwt:number=0;
estimatewt:number=0;
@Output() getModel = new EventEmitter<JewelDetails[]>();

  constructor() { }

  ngOnInit(): void {
  }
  AddJewel()
  {
    let arr:JewelDetails=
    {
      jewelitem:this.jewelitem,
      noofitem:Number(this.noofitem),
      totalwt:this.totalwt,
      disallowedwt:Number(this.disallowedwt),
      estimatewt:this.estimatewt
    }

    this.jewelDetails.push(arr);
    this.jewelDetails = this.jewelDetails.reduce((accumalator:JewelDetails[], current) => {
      if(!accumalator.some(item => item.jewelitem === current.jewelitem)) {
        accumalator.push(current);
      }
      return accumalator;
    },[]);
    this.jewelitem="0";
    this.noofitem==0;
    this.disallowedwt==0;
    this.totalwt==0;
    this.estimatewt=0;
    $('#jewelitem').val('0');
    this.getModel.emit(this.jewelDetails);
  }
  DeleteRow(jewelitem:string)
    {
      this.jewelDetails.forEach((element,index)=>{
        if(element.jewelitem == jewelitem) this.jewelDetails.splice(index,1);
     });
    }
  ClearRow()
  {
    this.jewelitem="0";
    this.noofitem==0;
    this.disallowedwt==0;
    this.totalwt==0;
    this.estimatewt=0;
    $('#jewelitem').val('0');
  }
}
