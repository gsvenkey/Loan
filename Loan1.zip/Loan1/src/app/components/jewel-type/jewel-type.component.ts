import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import {ComboModel} from 'src/app/model/ComboModel';
import {JewelDetails} from 'src/app/model/JewelDetails';
declare var $:any;

@Component({
  selector: 'app-jewel-type',
  templateUrl: './jewel-type.component.html',
  styleUrls: ['./jewel-type.component.css']
})
export class JewelTypeComponent implements OnInit {
  jewelDetails:JewelDetails[]=[];
  jewelList:ComboModel[]=[];
  jewelitem:string="0";
  noofitem:number=0;
totalwt:number=0;
disallowedwt:number=0;
estimatewt:number=0;
@Output() getModel = new EventEmitter<JewelDetails[]>();
jewelId:string="0"
  constructor(private _apiService:APICall) { }

  ngOnInit() {
    this.GetJewelList();
  }
  selected(e:any) {
    this.jewelitem=$(e.target).find('option:selected').data('type');
  }
  GetJewelList()
  {
    this._apiService.BindJewelList().subscribe((result:ComboModel[]) => {
      this.jewelList=result;
      console.log(this.jewelList);
    });
  }
  AddJewel()
  {
    let arr:JewelDetails=
    {
      jewelMasterId:Number(this.jewelId),
      jewelitem:this.jewelitem,
      noOfItem:Number(this.noofitem),
      totalWeight:this.totalwt,
      disallowedWt:Number(this.disallowedwt),
      estimateWeight:this.estimatewt
    }

    this.jewelDetails.push(arr);
    this.jewelDetails = this.jewelDetails.reduce((accumalator:JewelDetails[], current) => {
      if(!accumalator.some(item => item.jewelMasterId === current.jewelMasterId)) {
        accumalator.push(current);
      }
      return accumalator;
    },[]);
    this.jewelId="0";
    this.noofitem=0;
    this.disallowedwt=0;
    this.totalwt=0;
    this.estimatewt=0;
    this.getModel.emit(this.jewelDetails);
  }
  DeleteRow(jewelitem:string)
    {
      this.jewelDetails.forEach((element,index)=>{
        if(element.jewelitem == jewelitem) this.jewelDetails.splice(index,1);
     });
    }
  ClearRow()
  {
    this.jewelitem="0";
    this.noofitem=0;
    this.disallowedwt=0;
    this.totalwt=0;
    this.estimatewt=0;
    $('#jewelitem').val('0');
  }
}
