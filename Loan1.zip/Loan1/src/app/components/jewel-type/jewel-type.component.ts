import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import {ComboModel} from 'src/app/model/ComboModel';
import {JewelDetails} from 'src/app/model/JewelDetails';
declare var $:any;

@Component({
  selector: 'app-jewel-type',
  templateUrl: './jewel-type.component.html',
  styleUrls: ['./jewel-type.component.css']
})
export class JewelTypeComponent implements OnInit {
  @Input() jewelDetails:JewelDetails[]=[];
  jewelList:ComboModel[]=[];
  jewelitem:string="0";
  noofitem:number=0;
totalwt:number=0;
disallowedwt:number=0;
estimatewt:number=0;
@Output() getModel = new EventEmitter<JewelDetails[]>();
jewelId:string="0"
jewelRate:number=0;
estimateAmount:number=0;
  constructor(private _apiService:APICall) { }

  ngOnInit() {
    this.GetJewelList();
    this.UpdateJewel();
  }
  estimatewtKeyup(e:any)
  {
    this.estimateAmount = Number(this.jewelRate) * Number(e.target.value);
  }
  selected(e:any) {
    this.jewelitem=$(e.target).find('option:selected').data('type');
    this._apiService.BindJewelRate(1).subscribe((result:number) => {
      debugger;
      this.jewelRate=result;
      if(this.jewelRate == 0)
      {
        alert("Please Update Jewel Current Market Price");
        this.ClearRow();
      }
    });
  }
  GetJewelList()
  {
    this._apiService.BindJewelList().subscribe((result:ComboModel[]) => {
      debugger;
      this.jewelList=result;
      console.log(this.jewelList);
    });
  }
  UpdateJewel()
  {
    this.jewelDetails.forEach(a=>
      {
        var jewewlItem:any=this.jewelList.find(b=>{return b.value==a.jewelMasterId.toString()});
         a.jewelitem=jewewlItem?.text
      });
  //   this.jewelDetails.forEach(a=>
  //     {
  //   let arr:JewelDetails=
  //   {
  //     jewelMasterId:Number(a.jewelMasterId),
  //     jewelitem:a.jewelitem,
  //     noOfItem:Number(a.noOfItem),
  //     totalWeight:a.totalWeight,
  //     disallowedWt:Number(a.disallowedWt),
  //     estimateWeight:a.estimateWeight
  //   }

  //   this.jewelDetails.push(arr);
  // });
  //   this.jewelDetails = this.jewelDetails.reduce((accumalator:JewelDetails[], current) => {
  //     if(!accumalator.some(item => item.jewelMasterId === current.jewelMasterId)) {
  //       accumalator.push(current);
  //     }
  //     return accumalator;
  //   },[]);
  //   this.jewelId="0";
  //   this.noofitem=0;
  //   this.disallowedwt=0;
  //   this.totalwt=0;
  //   this.estimatewt=0;
    this.getModel.emit(this.jewelDetails);
  }
  AddJewel()
  {
    let arr:JewelDetails=
    {
      jewelMasterId:Number(this.jewelId),
      jewelitem:this.jewelitem,
      noOfItem:Number(this.noofitem),
      totalWeight:this.totalwt,
      disallowedWt:Number(this.disallowedwt),
      estimateWeight:this.estimatewt,
      pacsValue: this.jewelRate,
      estimateAmount: Number(this.jewelRate) * Number(this.estimatewt)
    }

    this.jewelDetails.push(arr);
    this.jewelDetails = this.jewelDetails.reduce((accumalator:JewelDetails[], current) => {
      if(!accumalator.some(item => item.jewelMasterId === current.jewelMasterId)) {
        accumalator.push(current);
      }
      return accumalator;
    },[]);
    this.ClearRow();
    this.getModel.emit(this.jewelDetails);
  }
  DeleteRow(jewelitem:string)
    {
      this.jewelDetails.forEach((element,index)=>{
        if(element.jewelitem == jewelitem) this.jewelDetails.splice(index,1);
     });
    }
  ClearRow()
  {
    this.jewelId="0";
    this.noofitem=0;
    this.disallowedwt=0;
    this.totalwt=0;
    this.estimatewt=0;
    this.estimateAmount=0;
    this.jewelRate=0;
  }
}
