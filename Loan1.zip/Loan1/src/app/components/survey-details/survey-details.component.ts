import { Component, Input, OnInit, OnChanges, Output, EventEmitter } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-survey-details',
  templateUrl: './survey-details.component.html',
  styleUrls: ['./survey-details.component.css']
})
export class SurveyDetailsComponent implements OnChanges {
  surveyDetails: any=[];
  @Input() memberId: number = 0;

  constructor(private _apiService: APICall, private cookie: CookieService) { }

  ngOnChanges() {
    this.GetSurveyDetails();
  }

  ngOnInit() {
    console.log("ss"+this.surveyDetails);
  }

  GetSurveyDetails() {
    this._apiService.GetSurveyDetails(this.memberId).subscribe((result: any) => {
      this.surveyDetails = result;
      console.log(this.surveyDetails);
    });
  }
}
