import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {LandTypeModel} from 'src/app/model/LandTypeModel';

@Component({
  selector: 'app-land-type',
  templateUrl: './land-type.component.html',
  styleUrls: ['./land-type.component.css']
})
export class LandTypeComponent implements OnInit {
landDetails:LandTypeModel[]=[];
DOM:Date=new Date();
MRN:string='';
MA:number=0;
SRO:number=0;
SRD:number=0;
@Output() getModel = new EventEmitter<LandTypeModel[]>();

  constructor() { }

  ngOnInit(): void {
  }
  SetModel()
  {
    this.landDetails=[];
    var arr:LandTypeModel=
    {
      modifiedDate:new Date(),
        modifiedBy:1,
        message:'',
        loanRequestId:1,
        isDeleted:false,
        createdDate:new Date(),
        createdBy:1,
        id:1,
        dateOfMortgage:this.DOM,
        mortgageAmount:this.MA,
        mortgageRegNo:this.MRN,
        subRegisterId:this.SRO
    }
    this.landDetails.push(arr);
this.getModel.emit(this.landDetails);
  }
}
