import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {TieupModel} from 'src/app/model/TieupModel';
@Component({
  selector: 'app-tieup-type',
  templateUrl: './tieup-type.component.html',
  styleUrls: ['./tieup-type.component.css']
})
export class TieupTypeComponent implements OnInit {
  TieupDetails:TieupModel[]=[];
TCN:number=0;
TLD:Date = new Date();
MLA:number=0
@Output() getModel = new EventEmitter<TieupModel[]>();

  constructor() { }

  ngOnInit(): void {
  }
  setModel()
  {
    this.TieupDetails=[];
    var arr:TieupModel=
    {
      modifiedDate:new Date(),
      modifiedBy:1,
      message:'',
      loanRequestId:1,
      isDeleted:false,
      createdDate:new Date(),
      createdBy:1,
      id:1,
      maximumLoanAmount:this.MLA,
      tieUpCompanyId:this.TCN,
      tieupLetterDate:this.TLD
    }
    this.TieupDetails.push(arr);
    this.getModel.emit(this.TieupDetails);
  }

}
