import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TieupTypeComponent } from './tieup-type.component';

describe('TieupTypeComponent', () => {
  let component: TieupTypeComponent;
  let fixture: ComponentFixture<TieupTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TieupTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TieupTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
