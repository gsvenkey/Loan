import { Component, OnInit,Input, OnChanges, Output ,EventEmitter } from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import {ComboModel} from 'src/app/model/ComboModel';
import {CropDetails} from 'src/app/model/CropDetails';
declare var $:any;
@Component({
  selector: 'app-crop-details',
  templateUrl: './crop-details.component.html',
  styleUrls: ['./crop-details.component.css']
})
export class CropDetailsComponent implements OnChanges {
cropList:ComboModel[]=[];
categoryList:ComboModel[]=[];
totalAcre:number=0;
surveyDetails:any;
@Input() memberId: number=0;
category:string="";
crop:string="";
survey:string="";
acre:number=0;
cropId:number=0;
cropDetails:CropDetails[]=[];
duePeriod:number=0;
@Output() getCropDetails = new EventEmitter<CropDetails[]>();
loanDuePeriod:number=0;
requestAmount:number=0;
estimateAmount:number=0;
estimateAcre:number=0;
  constructor(private _apiService:APICall) { }

  ngOnChanges() {
    this.GetSurveyDetails();
    this.GetCategoryList();
    }   
    periodEnter(e:any)
    {
      this._apiService.GetCropPeriod(1,this.cropId).subscribe((result:number) => {
        this.duePeriod=result;
        this.loanDuePeriod=this.duePeriod+this.loanDuePeriod;
      });
    
    }
    acreEnter(e:any)
    {
      this.acre = e.target.value;
      if(e.target.value>this.totalAcre)
      {  
        this.acre = 0;
        e.target.value ='0';
     }
    
    }
 
    DeleteRow(crop:string,survey:string)
    {
      this.cropDetails.forEach((element,index)=>{
        if(element.crop == crop && element.surveyNo ==survey) this.cropDetails.splice(index,1);
     });
    }
    selectedSurvey(e:any)
    {
       this.totalAcre=$(e.target).find('option:selected').data('acre');
       this.survey=$(e.target).find('option:selected').text();
    }
    GetSurveyDetails()
  {
     //let id=Number(this.cookie.get("MemberId"));
    this._apiService.GetSurveyDetails(this.memberId).subscribe((result:any) => {
      this.surveyDetails=result;
      console.log(this.surveyDetails);
    });
  }
  AddCrop()
  {
    let arr:CropDetails=
    {
      category:this.category,
      acre:Number(this.acre),
      crop:this.crop,
      cropId:this.cropId,
      surveyNo:this.survey,
      cultivationAcre:this.totalAcre,
      duePeriod:this.duePeriod,
      requestAmount:this.requestAmount,
      estimateAmount:this.estimateAmount,
      loanDuePeriod:this.loanDuePeriod
    }

    this.cropDetails.push(arr);
    this.getCropDetails.emit(this.cropDetails);
    this.cropDetails = this.cropDetails.reduce((accumalator:CropDetails[], current) => {
      if(!accumalator.some(item => item.cropId === current.cropId && item.surveyNo === current.surveyNo)) {
        accumalator.push(current);
      }
      return accumalator;
    },[]);
    this.requestAmount=0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.requestAmount =  Number(this.requestAmount )+ Number(this.cropDetails[i].estimateAmount);
    }
    this.cropDetails.forEach(a=>{ a.requestAmount=this.requestAmount});
    this.estimateAcre=0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.estimateAcre =  Number(this.estimateAcre) + Number(this.cropDetails[i].acre);
    }
    this.category="0";
    this.acre=0;
    this.crop='';
    this.survey='0';
    this.totalAcre=0;
    this.duePeriod=0;
    this.estimateAmount=0;
    $('#survey').val('0');
    $('#crop').val('0');
    $('#category').val('0');
  }

  ClearRow()
  {
    this.category="0";
    this.acre=0;
    this.crop='';
    this.survey='0';
    this.totalAcre=0;
    this.duePeriod=0;
    this.estimateAmount=0;
    $('#survey').val('0');
    $('#crop').val('0');
    $('#category').val('0');
  }
  GetCategoryList()
  {
    this._apiService.BindCropCategoryList().subscribe((result:ComboModel[]) => {
      debugger;
      this.categoryList=result;
      console.log(this.cropList);
    });
  }
  selectedCategory(e:any) {
    let id:number = e.target.value;
  this.category=$(e.target).find('option:selected').text();
    this._apiService.BindCropListByCategory(id).subscribe((result:ComboModel[]) => {
      debugger;
      this.cropList=result;
      console.log(this.cropList);
    });
  }
  selected(e:any) {
    this.cropId = e.target.value;
  this.crop=$(e.target).find('option:selected').text();
  this._apiService.GetCropPeriod(1,this.cropId).subscribe((result:number) => {
    this.duePeriod=result;
    this.loanDuePeriod=this.duePeriod+this.loanDuePeriod;
  });
  }

}
