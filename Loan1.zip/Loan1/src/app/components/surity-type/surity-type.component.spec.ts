import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SurityTypeComponent } from './surity-type.component';

describe('SurityTypeComponent', () => {
  let component: SurityTypeComponent;
  let fixture: ComponentFixture<SurityTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SurityTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SurityTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
