import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VaoListComponent } from './vao-list.component';

describe('VaoListComponent', () => {
  let component: VaoListComponent;
  let fixture: ComponentFixture<VaoListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VaoListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VaoListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
