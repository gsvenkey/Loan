import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vao-list',
  templateUrl: './vao-list.component.html',
  styleUrls: ['./vao-list.component.css']
})
export class VaoListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
