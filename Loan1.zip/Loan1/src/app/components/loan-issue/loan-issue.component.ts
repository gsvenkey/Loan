import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanIssueModel,LoanIssueDetails } from 'src/app/model/LoanIssueModel';
import{LoanIssueListModel} from 'src/app/model/LoanIssueListModel';
import{ValidationModel} from 'src/app/model/ValidationModel';
import { DatePipe } from '@angular/common'
declare var $:any
@Component({
  providers: [DatePipe],
  selector: 'app-loan-issue',
  templateUrl: './loan-issue.component.html',
  styleUrls: ['./loan-issue.component.css']
})
export class LoanIssueComponent implements OnInit {

  loanTypList: ComboModel[] = [];
  loanTypeId: number = 0;
  
  sanctionNoList: ComboModel[] = [];
  memberList: ComboModel[] = [];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  mobile: string = "";
  photoUrl: string = "";
  IsShowList: boolean = false;
  SanctionDate: any = this.datepipe.transform(new Date(),'dd-MM-yyyy');
  loanIssueDetails: LoanIssueDetails[] = [];
  MemberId:string='0';
  SanctionId:string='0';
  loanNo:string='';
  loanType:string='';
  LoanDueDate:Date=new Date();
  issueId:number=0;
  list:LoanIssueListModel[]=[];
  Total:number=0;
  EligibleAmount:number=0;
  OutstandingAmount:number=0;
  constructor(public datepipe: DatePipe,private _apiService: APICall) { }

  ngOnInit() {
    this.GetMemberList();
    //this.GetSanctionNoList();
  }
  setLoanDetails(e:any)
  {
this.MemberId=e.memberID;
this.SanctionId=e.sanctionId;
this.loanNo=e.loanNo;
this.issueId=e.id;
this._apiService.BindLoanType().subscribe((result:ComboModel[]) => {
  var loan:any=result.find(a=>{return a.value==e.loanTypeID});
  this.loanType=loan.text;
    });
$('#Member').trigger('change');

  }
  GetLoanList()
  {
    this._apiService.BindLoanIssueList(1,1).subscribe((result:LoanIssueListModel[]) => {
      this.list=result;
      console.log(this.list);
    });
  }
  List() {
    this.IsShowList = true;
    this.GetLoanList();
  }
  Clear() {
    this.MemberId='0';
    this.SanctionId='0';
    this.loanIssueDetails=[];
    this.loanType='';
    this.loanNo='';
    this.Total=0;
    this.memberName = '';
    this.memberAdd1 = '';
    this.memberAdd2 = '';
    this.memberAdd3 = '';
    this.mobile = '';
    this.photoUrl = '';
    this.OutstandingAmount=0;
    this.EligibleAmount=0;
    this.LoanDueDate=new Date();
  }
  Save() {

    this.loanIssueDetails.forEach(a => { a.id = 0 });

    var model:LoanIssueModel=
    {
      createdBy:0,
      createdDate:new Date(),
      dueDate:this.LoanDueDate,
      fYearId:1,
      id:this.issueId,
      isDeleted:false,
      issueAmount:this.Total,
      issueDate:new Date(),
      issueNo:0,
      loanIssueDetails:this.loanIssueDetails,
      loanNo:this.loanNo,
      loanTypeID:this.loanTypeId,
      memberID:Number(this.MemberId),
      message:'',
      modifiedBy:0,
      modifiedDate:new Date(),
      pacsId:1,
      rateOfInterestId:0,
      sanctionId:Number(this.SanctionId)
    }
this._apiService.LoanIssueValidation(model).subscribe((result: ValidationModel) => {
  if(result.isValid)
  {
    this.SaveIssue(model);
   
  }
else if(result.warningMessage != '')
{
  if(confirm(result.warningMessage)){

    this.SaveIssue(model);
  }
  else if(result.validationMessage!='')
  {
    alert(result.validationMessage);
  }
}
});
  }

  SaveIssue(model:LoanIssueModel)
  {
    if(this.issueId==0)
    {
    this._apiService.SaveLoanIssue(model).subscribe((result: boolean) => {
      if (result) {
        alert('success')
      }
      else {
        alert('failed to save')
      }
    });
  }
  else
  {
    this._apiService.UpdateLoanIssue(this.issueId, model).subscribe((result: boolean) => {
      if (result) {
        alert('success')
      }
      else {
        alert('failed to save')
      }
    });
  }
  }
  selected(e: any) {
    let id: number = e.target.value;
    this._apiService.GetMemberInfo(id).subscribe((result: any) => {
       if(result!=null)
      {
      this.memberName = result.name;
      this.memberAdd1 = result.address1;
      this.memberAdd2 = result.address2;
      this.memberAdd3 = result.address3;
      this.mobile = result.mobileNumber;
      this.photoUrl = result.photoUrl;
      this.OutstandingAmount=result.outstandingAmount;
      }
      else
      {
        this.memberName = '';
        this.memberAdd1 = '';
        this.memberAdd2 = '';
        this.memberAdd3 = '';
        this.mobile = '';
        this.photoUrl = '';
        this.OutstandingAmount=0;
      }
    });
    this.GetSanctionNoList(id);
  }
  // GetLoanTypes()
  // {
  //   this._apiService.BindLoanType().subscribe((result:ComboModel[]) => {
  //     this.loanTypList=result;
  //     console.log(this.loanTypList);
  //   });
  // }
  GetSanctionNoList(id: number) {
    this._apiService.GetSanctionNoList(1, id).subscribe((result: ComboModel[]) => {
      this.sanctionNoList = result;
      
    });
  }
  GetMemberList() {
    this._apiService.BindMember(1).subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }

  calculatePreTotal(i:number)
  {
    let pretotal:number=0;
    for(let j=0;j<=$($('.table tbody>tr')[i]).find('.precalculate input[type="text"]').length;j++)
    {
      let val:number=$($($('.table tbody>tr')[i]).find('.precalculate input[type="text"]')[j]).val();
      if(val!=undefined)
      {
          pretotal = Number(pretotal)+ Number($($($('.table tbody>tr')[i]).find('.precalculate input[type="text"]')[j]).val())
      }
    }

    this.loanIssueDetails[i].preTotal=pretotal;
    this.loanIssueDetails[i].grandTotal= Number(this.loanIssueDetails[i].kindTotal) + Number(pretotal);
    this.Total=0;

    this.loanIssueDetails.forEach(a=> { 
      this.Total = Number(this.Total)+ Number(a.grandTotal)
    });
  }

  calculateKindTotal(i:number)
  {
    let kindTotal:number=0;
    for(let j=0;j<=$($('.table tbody>tr')[i]).find('.kindcalculate input[type="text"]').length;j++)
    {
      let val:number=$($($('.table tbody>tr')[i]).find('.kindcalculate input[type="text"]')[j]).val();
      if(val!=undefined)
      {
      kindTotal = Number(kindTotal)+ Number($($($('.table tbody>tr')[i]).find('.kindcalculate input[type="text"]')[j]).val())
      }
    }

    this.loanIssueDetails[i].kindTotal=kindTotal;
    this.loanIssueDetails[i].grandTotal= Number(this.loanIssueDetails[i].preTotal) + Number(kindTotal);
    this.Total=0;

    this.loanIssueDetails.forEach(a=> { 
      this.Total = Number(this.Total)+ Number(a.grandTotal)
    });

  }

  selectedSanction(e: any) {
    this.loanIssueDetails = [];
    let id: number = e.target.value;
    this._apiService.GetLoanSanctionDetailsById(id).subscribe((result: LoanIssueModel) => {

      this.loanIssueDetails = result.loanIssueDetails;
      this.loanIssueDetails.forEach(a=> { if(a.manure == null){a.manure=0}});
      this.Total = 0;
          this.loanTypeId = result.loanTypeID;
          this._apiService.BindLoanType().subscribe((result: ComboModel[]) => {
          let loan:any=result.find(a=> { return a.value == this.loanTypeId.toString()});
           this.loanType=loan.text;
          });
          for (let i = 0; i < this.loanIssueDetails.length; i++) {

            this.loanIssueDetails[i].preTotal= Number(this.loanIssueDetails[i].cash) +
            Number(this.loanIssueDetails[i].seed) + Number(this.loanIssueDetails[i].manure) +
            Number(this.loanIssueDetails[i].pesticide);

            this.loanIssueDetails[i].kindTotal=Number(this.loanIssueDetails[i].kindSeed) + 
            Number(this.loanIssueDetails[i].kindFertilizer) + Number(this.loanIssueDetails[i].kindPesticide);

            this.loanIssueDetails[i].grandTotal=this.loanIssueDetails[i].preTotal + this.loanIssueDetails[i].kindTotal;

            this.Total = Number(this.Total) + Number(this.loanIssueDetails[i].cash) +
              Number(this.loanIssueDetails[i].seed) + Number(this.loanIssueDetails[i].manure) +
              Number(this.loanIssueDetails[i].pesticide) + Number(this.loanIssueDetails[i].kindSeed) + 
              Number(this.loanIssueDetails[i].kindFertilizer) + Number(this.loanIssueDetails[i].kindPesticide);
          }
          if(this.loanType!="JLG")
          {
            this._apiService.GetMaxLimitByLoanType(this.loanTypeId).subscribe((result: number) => {
              
            this.EligibleAmount= Number(result-this.OutstandingAmount);
            if(this.EligibleAmount<= Number(result))
            {
              this.EligibleAmount=this.EligibleAmount;
            }
            else
            {
              this.EligibleAmount= result;
            }
            });
          }
    });
  }

}
