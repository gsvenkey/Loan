import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-project-dash-board',
  templateUrl: './project-dash-board.component.html',
  styleUrls: ['./project-dash-board.component.css']
})
export class ProjectDashBoardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void  {
    if ( $.fn.DataTable.isDataTable('#tbl_project_dashboard') ) {
      $('#tbl_project_dashboard').DataTable().destroy();
    }
    var table = $('#tbl_project_dashboard').DataTable();
  }
}
