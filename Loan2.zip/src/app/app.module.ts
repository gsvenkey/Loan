import { BrowserModule } from '@angular/platform-browser';
import { NgModule,APP_INITIALIZER } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';  
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { MemberDetailsComponent } from './components/member-details/member-details.component';
import { SurveyDetailsComponent } from './components/survey-details/survey-details.component';
import { CropDetailsComponent } from './components/crop-details/crop-details.component';
import { SurityTypeComponent } from './components/surity-type/surity-type.component';
import { JewelTypeComponent } from './components/jewel-type/jewel-type.component';
import { CookieService } from 'ngx-cookie-service';
import { LandTypeComponent } from './components/land-type/land-type.component';
import { TieupTypeComponent } from './components/tieup-type/tieup-type.component';
import { CapitalTypeComponent } from './components/capital-type/capital-type.component';
import { JlgTypeComponent } from './components/jlg-type/jlg-type.component';
import { LoanProcessingListComponent } from './components/loan-processing-list/loan-processing-list.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    AdministrationComponent,
    MemberDetailsComponent,
    SurveyDetailsComponent,
    CropDetailsComponent,
    SurityTypeComponent,
    JewelTypeComponent,
    LandTypeComponent,
    TieupTypeComponent,
    CapitalTypeComponent,
    JlgTypeComponent,
    LoanProcessingListComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [CookieService],
  
  bootstrap: [AppComponent]
})
export class AppModule { }
