import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CapitalTypeComponent } from './capital-type.component';

describe('CapitalTypeComponent', () => {
  let component: CapitalTypeComponent;
  let fixture: ComponentFixture<CapitalTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CapitalTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CapitalTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
