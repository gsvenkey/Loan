import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JlgTypeComponent } from './jlg-type.component';

describe('JlgTypeComponent', () => {
  let component: JlgTypeComponent;
  let fixture: ComponentFixture<JlgTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JlgTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JlgTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
