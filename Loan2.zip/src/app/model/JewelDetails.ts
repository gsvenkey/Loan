export class JewelDetails{
    jewelitem:string="";
        noofitem:number=0;
    totalwt:number=0;
    disallowedwt:number=0;
    estimatewt:number=0;
        constructor()
        {
    
        }
    }