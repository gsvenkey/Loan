import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './components/home/home.component';
import { CapabilitySearchComponent } from './components/capability-search/capability-search.component';
import { ProductSearchComponent } from './components/product-search/product-search.component';
import { ProjectDashBoardComponent } from './components/project-dash-board/project-dash-board.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { MemberDetailsComponent } from './components/member-details/member-details.component';
import { SurveyDetailsComponent } from './components/survey-details/survey-details.component';
import { CropDetailsComponent } from './components/crop-details/crop-details.component';
import { SurityTypeComponent } from './components/surity-type/surity-type.component';
import { JewelTypeComponent } from './components/jewel-type/jewel-type.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    CapabilitySearchComponent,
    ProductSearchComponent,
    ProjectDashBoardComponent,
    AdministrationComponent,
    MemberDetailsComponent,
    SurveyDetailsComponent,
    CropDetailsComponent,
    SurityTypeComponent,
    JewelTypeComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
