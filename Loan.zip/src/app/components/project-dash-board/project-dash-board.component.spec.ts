import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectDashBoardComponent } from './project-dash-board.component';

describe('ProjectDashBoardComponent', () => {
  let component: ProjectDashBoardComponent;
  let fixture: ComponentFixture<ProjectDashBoardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProjectDashBoardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectDashBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
