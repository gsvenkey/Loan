import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jewel-type',
  templateUrl: './jewel-type.component.html',
  styleUrls: ['./jewel-type.component.css']
})
export class JewelTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
