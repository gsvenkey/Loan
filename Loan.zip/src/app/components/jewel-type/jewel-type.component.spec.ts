import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JewelTypeComponent } from './jewel-type.component';

describe('JewelTypeComponent', () => {
  let component: JewelTypeComponent;
  let fixture: ComponentFixture<JewelTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JewelTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JewelTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
