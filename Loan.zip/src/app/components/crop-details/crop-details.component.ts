import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crop-details',
  templateUrl: './crop-details.component.html',
  styleUrls: ['./crop-details.component.css']
})
export class CropDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
