import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-surity-type',
  templateUrl: './surity-type.component.html',
  styleUrls: ['./surity-type.component.css']
})
export class SurityTypeComponent implements OnInit {
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  mobile: string = "";
  constructor() { }

  ngOnInit(): void {

  }

  selected() {
    this.memberName = "Vijay,";
    this.memberAdd1 = "1st Street,";
    this.memberAdd2 = "2nd Nagar,";
    this.memberAdd3 = "Medavakkam,Chennai";
    this.mobile="1234567890";
  }

}
