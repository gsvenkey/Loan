import { Component, OnInit } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css']
})
export class ProductSearchComponent implements OnInit {
  constructor() { }
  ngOnInit(): void  {
    if ( $.fn.DataTable.isDataTable('#tbl_productsearch') ) {
      $('#tbl_productsearch').DataTable().destroy();
    }
    var table = $('#tbl_productsearch').DataTable();
  }
}
