import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-survey-details',
  templateUrl: './survey-details.component.html',
  styleUrls: ['./survey-details.component.css']
})
export class SurveyDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
