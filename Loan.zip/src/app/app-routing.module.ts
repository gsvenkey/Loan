import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { CapabilitySearchComponent } from './components/capability-search/capability-search.component';
import { ProductSearchComponent } from './components/product-search/product-search.component';
import { ProjectDashBoardComponent } from './components/project-dash-board/project-dash-board.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { SurityTypeComponent } from './components/surity-type/surity-type.component';
import { JewelTypeComponent } from './components/jewel-type/jewel-type.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'capability-search', component: CapabilitySearchComponent },
  { path: 'product-search', component: ProductSearchComponent },
  { path: 'project-Dashboard', component: ProjectDashBoardComponent },
  { path: 'administration', component: AdministrationComponent },
  { path: 'SurityType', component: SurityTypeComponent },
  { path: 'JewelType', component: JewelTypeComponent },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent = [HomeComponent]
