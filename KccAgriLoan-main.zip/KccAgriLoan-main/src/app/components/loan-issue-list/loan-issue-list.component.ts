import { Component, OnInit ,Output,EventEmitter} from '@angular/core';
import {APICall} from 'src/app/services/APICall.Services';
import{LoanIssueListModel} from 'src/app/model/LoanIssueListModel';
import { LoanIssueModel,LoanIssueDetails } from 'src/app/model/LoanIssueModel';

@Component({
  selector: 'app-loan-issue-list',
  templateUrl: './loan-issue-list.component.html',
  styleUrls: ['./loan-issue-list.component.css']
})
export class LoanIssueListComponent implements OnInit {
  @Output() getLoanDetails = new EventEmitter<LoanIssueModel>();
  list:LoanIssueListModel[]=[];
  constructor(private _apiService:APICall) { }

  ngOnInit() {
    this.GetLoanList();
  }
  GetLoanList()
  {
    this._apiService.BindLoanIssueList(1,1).subscribe((result:LoanIssueListModel[]) => {
      this.list=result;
      console.log(this.list);
    });
  }
  Edit(id:number)
  {
    this._apiService.GetLoanIssueDetails(id).subscribe((result:LoanIssueModel) => {
      this.getLoanDetails.emit(result);
    });
  }
  Delete(id:number)
  {
    if (confirm('Are you sure want to delete this item?')) {
      this._apiService.DeleteLoanIssueRequest(id).subscribe((result:boolean) => {
        if(result)
        {
          alert("success");
          this.GetLoanList();
        }
        else
        {
          alert("failure")
        }
      });
     
    } else {
      // Do nothing!
      console.log('Thing was not saved to the database.');
    }
    
  }
}
