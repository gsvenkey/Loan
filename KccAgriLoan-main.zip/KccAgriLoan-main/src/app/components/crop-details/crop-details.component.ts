import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { CropDetails } from 'src/app/model/CropDetails';
import { analyzeAndValidateNgModules } from '@angular/compiler';
declare var $: any;
@Component({
  selector: 'app-crop-details',
  templateUrl: './crop-details.component.html',
  styleUrls: ['./crop-details.component.css']
})
export class CropDetailsComponent implements OnChanges {
  vaoDetailId:number=0;
  cropList: ComboModel[] = [];
  categoryList: ComboModel[] = [];
  totalAcre: number = 0;
  surveyDetails: any;
  @Input() memberId: number = 0;
  category: string = "";
  crop: string = "";
  survey: string = "";
  acre: number = 0;
  cropId: number = 0;
  @Input() cropDetails: CropDetails[] = [];
  duePeriod: number = 0;
  @Output() getCropDetails = new EventEmitter<CropDetails[]>();
  loanDuePeriod: number = 0;
  requestAmount: number = 0;
  estimateAmount: number = 0;
  estimateAcre: number = 0;
  CategoryId:string='0';
  constructor(private _apiService: APICall) { }

  ngOnChanges() {
    this.GetSurveyDetails();
    this.GetCategoryList();
    this.UpdateCrop();
  }
  periodEnter() {
    // this._apiService.GetCropPeriod(1, this.cropId).subscribe((result: number) => {
    //   this.duePeriod = result;
    //   this.loanDuePeriod = this.duePeriod + this.loanDuePeriod;
    // });
    if(this.cropDetails.length!=0)
    {
let period:number = this.cropDetails[0].duePeriod;
if(period!=this.duePeriod)
{
  alert("Due Period should be equal in all the items.")
  this.duePeriod=0;
}
    }
  }
  acreEnter(e: any) {
    this.acre = e.target.value;
    if (e.target.value > this.totalAcre) {
      this.acre = 0;
      e.target.value = '0';
      return;
    }
    if(this.cropDetails.length!=0)
    {
    let crops:CropDetails[]=[];
    this.cropDetails.forEach(a=>{if(a.surveyNo.trim()==$('#survey option:selected').text().trim()){ crops.push(a)}});
    let totalsurveyacre:number=0;
    crops.forEach(element => {
      totalsurveyacre = Number(totalsurveyacre) + Number(element.acre);
    });
    totalsurveyacre = Number(totalsurveyacre)+Number(this.acre);
    if(totalsurveyacre>this.cropDetails[0].cultivationAcre)
    {
      this.acre = 0;
      e.target.value = '0';
      alert("Acre exceed");
    }
  }
    this._apiService.GetLoanEstimationAmount(1, this.cropId, this.acre).subscribe((result: number) => {
      this.estimateAmount = result;
    });
  }

  DeleteRow(crop: string, survey: string) {
    this.cropDetails.forEach((element, index) => {
      if (element.cropName == crop && element.surveyNo == survey) this.cropDetails.splice(index, 1);
    });
  }
  selectedSurvey(e: any) {
    this.totalAcre = $(e.target).find('option:selected').data('acre');
    this.vaoDetailId = $(e.target).find('option:selected').data('vaodetailid');

    this.survey = $(e.target).find('option:selected').text();
  }
  GetSurveyDetails() {
    //let id=Number(this.cookie.get("MemberId"));
    this._apiService.GetSurveyDetails(this.memberId).subscribe((result: any) => {
      this.surveyDetails = result;
      console.log(this.surveyDetails);
    });
  }
  UpdateCrop()
  {
if(this.cropDetails.length!=0 && this.cropDetails !=undefined)
{
    let updatedcrop:CropDetails[]=this.cropDetails;
    this.cropDetails=[];
    updatedcrop.forEach(a=>
      {

        let arr: CropDetails =
    {
      cropCategoryName:a.cropCategoryName,
      acre: Number(a.acre),
      cropName:a.cropName,
      cropId: a.cropId,
      cropCategoryId:Number(a.cropCategoryId),
      vaoDetailId:a.vaoDetailId,
      surveyNo: a.vaoDetail.serveyNo,
      cultivationAcre: a.cultivationAcre,
      duePeriod: a.loanDuePeriod,
      requestAmount: a.requestAmount,
      estimateAmount: a.estimateAmount,
      loanDuePeriod: a.loanDuePeriod,
      vaoDetail:a.vaoDetail
    }
    this.cropDetails.push(arr);
      })
      this.cropDetails.forEach(a => {
        this._apiService.GetLoanEstimationAmount(1, a.cropId, a.acre).subscribe((result: number) => {
          a.estimateAmount = result;
        });

       });

    this.getCropDetails.emit(this.cropDetails);
    this.requestAmount = updatedcrop[0].requestAmount;
    this.cropDetails.forEach(a => { a.requestAmount = this.requestAmount });
    this.estimateAcre = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.estimateAcre = Number(this.estimateAcre) + Number(this.cropDetails[i].acre);
    }
  }
  }
  AddCrop() {

    let arr: CropDetails =
    {
      cropCategoryName: this.category,
      acre: Number(this.acre),
      cropName: this.crop,
      cropId: this.cropId,
      cropCategoryId:Number(this.CategoryId),
      vaoDetailId:this.vaoDetailId,
      surveyNo: this.survey.trim(),
      cultivationAcre: this.totalAcre,
      duePeriod: this.duePeriod,
      requestAmount: this.requestAmount,
      estimateAmount: this.estimateAmount,
      loanDuePeriod: this.duePeriod,
      vaoDetail:null
    }
    this.cropDetails.push(arr);

    this.getCropDetails.emit(this.cropDetails);
    this.cropDetails = this.cropDetails.reduce((accumalator: CropDetails[], current) => {
      if (!accumalator.some(item => item.cropId === current.cropId && item.surveyNo === current.surveyNo)) {
        accumalator.push(current);
      }
      return accumalator;
    }, []);
    this.requestAmount = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.requestAmount = Number(this.requestAmount) + Number(this.cropDetails[i].estimateAmount);
    }
    this.cropDetails.forEach(a => { a.requestAmount = this.requestAmount });
    this.estimateAcre = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.estimateAcre = Number(this.estimateAcre) + Number(this.cropDetails[i].acre);
    }
    this.category = "0";
    this.acre = 0;
    this.crop = '';
    this.survey = '0';
    this.totalAcre = 0;
    this.duePeriod = 0;
    this.estimateAmount = 0;
    $('#survey').val('0');
    $('#crop').val('0');
    $('#category').val('0');
    this.CategoryId='0'
  }

  ClearRow() {
    this.category = "0";
    this.acre = 0;
    this.crop = '';
    this.survey = '0';
    this.totalAcre = 0;
    this.duePeriod = 0;
    this.estimateAmount = 0;
    $('#survey').val('0');
    $('#crop').val('0');
    $('#category').val('0');
    this.CategoryId='0'
  }
  GetCategoryList() {
    this._apiService.BindCropCategoryList().subscribe((result: ComboModel[]) => {
      debugger;
      this.categoryList = result;
      console.log(this.cropList);
    });
  }
  selectedCategory(e: any) {
    let id: number = e.target.value;
    this.category = $(e.target).find('option:selected').text();
    this._apiService.BindCropListByCategory(1,id).subscribe((result: ComboModel[]) => {
      debugger;
      this.cropList = result;
      console.log(this.cropList);
    });
  }
  selected(e: any) {
    this.cropId = e.target.value;
    this.crop = $(e.target).find('option:selected').text();
    this._apiService.GetCropPeriod(1, this.cropId).subscribe((result: number) => {
      this.duePeriod = result;
      // this.loanDuePeriod = this.duePeriod + this.loanDuePeriod;
    });
  }

}
