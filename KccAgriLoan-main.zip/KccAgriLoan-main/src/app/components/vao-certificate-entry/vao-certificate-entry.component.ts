import { Component, OnInit } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
@Component({
  selector: 'app-vao-certificate-entry',
  templateUrl: './vao-certificate-entry.component.html',
  styleUrls: ['./vao-certificate-entry.component.css']
})
export class VaoCertificateEntryComponent implements OnInit {
  memberList: ComboModel[] = [];
  Acre:number =0;
  LandInId:number =0;
  RevenueId:number =0;
  IrrigationId:number =0;
  FirkaId:number =0;
  OwnerId:number =0;
  MemberId:number =0;
  DOE:Date=new Date();
  CD:Date=new Date();

  constructor(private _apiService: APICall) { }

  ngOnInit() {
    this.GetMemberList();
  }
  List()
  {

  }
  Save()
  {

  }
  Clear()
  {
    
  }
  GetMemberList() {
    this._apiService.BindMember(1).subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }
  selected(e: any) {
    let id: number = e.target.value;
    this._apiService.GetMemberInfo(id).subscribe((result: any) => {
     
    });
  }
}
