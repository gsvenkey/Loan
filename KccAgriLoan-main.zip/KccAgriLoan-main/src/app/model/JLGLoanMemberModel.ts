export class JLGLoanMemberModel
{
    id: number = 0
      createdDate: Date =new Date()
      modifiedDate: Date =new Date()
      isDeleted: boolean = false
      createdBy: number = 0
      modifiedBy: number = 0
      message: string =''
      loanRequestId: number = 0
      memberId: number = 0
      name:string=''
      mobileNo:string=''
      AadharNo:string=''
      photoUrl:string=''
    constructor()
    {

    }
}