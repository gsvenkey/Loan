import{vaoDetail} from 'src/app/model/CropDetails'


export class sanctionDetail{
    id: number=0
    createdDate:Date=new Date()
    modifiedDate: Date=new Date()
    isDeleted: boolean=false
    createdBy: number=0
    modifiedBy: number=0
    message: string =''
    sanctionId: number=0
    cropId: number=0
    vaoDetailId: number=0
    loanDuePeriod: number=0
    cultivationAcre: number=0
    sanctionAcre: number=0
    cash: number=0
    seed: number=0
    fertilizer: number=0
    pesticide: number=0
    kindFertilizer: number=0
    kindSeed: number=0
    kindPesticide: number=0
    maintanance: number=0
    vaoDetail: any
    cropName: string =''
    cropNameInTamil: string=''
    constructor()
    {

    }
}

export class LoanIssueDetails{
    id: number=0
      createdDate: Date=new Date()
      modifiedDate: Date=new Date()
      isDeleted: boolean=false
      createdBy: number=0
      modifiedBy: number=0
      message: string=''
      issueId: number=0
      sanctionDetailId: number=0
      cropId: number=0
      loanDuePeriod: number=0
      vaoDetailId: number=0
      sanctionAcre: number=0
      issueAcre: number=0
      cash: number=0
      seed: number=0
      manure: number=0
      pesticide: number=0
      kindFertilizer: number=0
      kindSeed: number=0
      kindPesticide: number=0
      cropName: string=''
      cropNameInTamil: string=''
      sanctionDetail: any
    constructor()
    {

    }
}
export class LoanIssueModel{
    id: number=0
  createdDate: Date=new Date()
  modifiedDate: Date=new Date()
  isDeleted: boolean=false
  createdBy: number=0
  modifiedBy: number=0
  message: string=''
  sanctionId: number=0
  pacsId: number=0
  fYearId: number=0
  loanTypeID: number=0
  rateOfInterestId: number=0
  memberID: number=0
  issueNo: number=0
  loanNo: string=''
  issueDate:Date=new Date()
  dueDate:Date=new Date()
  issueAmount: number=0
  loanIssueDetails: LoanIssueDetails[]=[]
      
    constructor()
    {

    }
}
