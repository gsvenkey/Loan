export class LoanSanctionListModel
{
    id: number=0
    requestNo: number=0
    sanctionNo: number=0
    sanctionDate: Date = new Date()
    memberName: string =''
    loanType: string =''
    pacsId: number=0
    fYearId: number=0
    adhaarNumber: number=0
    constructor()
    {

    }
}