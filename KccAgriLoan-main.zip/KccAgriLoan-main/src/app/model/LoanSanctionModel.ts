export class LoanSanctionModel
{

loanRequestId: number=0
loanTypeID: number=0
pacsId: number=0
fYearId: number=0
sanctionNo: number=0
sanctionDate: Date=new Date()
memberID: number=0
sanctionAmount: number=0
loanSanctionDetails: LoanSanctionDetails[] =[]
id: number=0
// createdDate: string=''
// modifiedDate: string=''
// isDeleted: boolean =false
// createdBy: string=''
// modifiedBy: string=''
// message: string=''
constructor()
{

}
}

export class LoanSanctionDetails
{
    sanctionId: number=0
    cropId: number=0
    vaoDetailId: number=0
    loanDuePeriod: number=0
    cultivationAcre: number=0
    sanctionAcre: number=0
    cash: number=0
    seed: number=0
    fertilizer: number=0
    pesticide: number=0
    acreCash:number=0
    kindFertilizer: number=0
    kindSeed: number=0
    kindPesticide: number=0
    maintanance: number=0
    vaoDetail: any
    id: number=0
    createdDate: string=''
    modifiedDate: string=''
    isDeleted: boolean=false
    createdBy: string=''
    modifiedBy: string=''
    message: string=''
    constructor()
    {

    }
}