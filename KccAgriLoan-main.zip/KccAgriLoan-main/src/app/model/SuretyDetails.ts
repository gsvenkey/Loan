export class SuretyDetails{
    memberId:number=0
}