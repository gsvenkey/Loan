export class JewelDetails{
    jewelMasterId:number=0
    jewelitem:string="";
    noOfItem:number=0;
    totalWeight:number=0;
    disallowedWt:number=0;
    estimateWeight:number=0;
        constructor()
        {
    
        }
    }