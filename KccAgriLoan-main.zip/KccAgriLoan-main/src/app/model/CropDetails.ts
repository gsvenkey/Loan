export class CropDetails{
cropId:number=0;
surveyNo:string='';
acre:number=0;
loanDuePeriod:number=0;
cultivationAcre:number=0;
requestAmount:number=0;
duePeriod:number=0;
estimateAmount:number=0;
vaoDetailId:number=0;
cropCategoryId:number=0;
vaoDetail:any
cropCategoryName:string=''
cropName:string=''
    constructor()
    {

    }
}

export class vaoDetail{
        id: number=0
        createdDate: Date=new Date()
        modifiedDate: Date=new Date()
        isDeleted: boolean=false
        createdBy: number=0
        modifiedBy: number=0
        message: string=''
        vaoCertificateId: number=0
        serveyNo: string=''
        subDivisionNo: string=''
        totalArea: number=0
        bounded: number=0
    constructor()
    {

    }
}