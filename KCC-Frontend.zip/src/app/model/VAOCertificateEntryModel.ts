export class CertificateDetails {
  id:number=0;
  subDivision: string = "";
  surveyNo: number = 0;
  totalArea: number = 0;
  bounded: number = 0;
  constructor() {

  }
}
