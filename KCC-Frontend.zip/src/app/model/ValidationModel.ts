export class ValidationModel
{
    isValid: boolean=false
    warningMessage: string=''
    validationMessage: string=''
    constructor()
    {
        
    }
}