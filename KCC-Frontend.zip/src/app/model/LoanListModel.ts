export class LoanListModel
{
    id: number =0
    requestNo: number= 0
    requestDate: Date = new Date()
    memberName: string=''
    loanType: string=''
    pacsId: number=0
    fYearId: number=0
    adhaarNumber: number=0
    constructor()
    {

    }
}