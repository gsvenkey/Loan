import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ComboModel } from 'src/app/model/ComboModel';
import { ConfigServicesService } from 'src/app/services/config-services.service';
import { Observable } from 'rxjs';
import { map } from 'jquery';

@Injectable({
  providedIn: 'root'
})
export class LookUp {
  constructor(private httpClient: HttpClient, private configService: ConfigServicesService) {
  }
  baseUrl: string = this.configService.config.BaseApiUrl;
  pacsID: string = this.configService.config.pacsId;

  GetLookUpList(Code: string) {
   return this.httpClient.get<any[]>(this.baseUrl + 'LookUpCode/SelectlookUpInTamil/' + Code);
  }
}
