import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ConfigServicesService } from 'src/app/services/config-services.service';
import { Observable } from 'rxjs';
import { map } from 'jquery';

@Injectable({
  providedIn: 'root'
})
export class VAOCertificateEntry {
  constructor(private httpClient: HttpClient, private configService: ConfigServicesService) {
  }
  baseUrl: string = this.configService.config.BaseApiUrl;
  pacsID: string = this.configService.config.pacsId;

  GetFirkaList() {
    return this.httpClient.get<any[]>(this.baseUrl + 'FirkaMaster/SelectFirka/' + this.pacsID);
  }
  GetRevenueVillageList(Firka: string) {
    return this.httpClient.get<any[]>(this.baseUrl + 'RevenueVillageMaster/SelectRevenueVillage/' + Firka);
  }
  GetLandInVillageMasterList(RevenueVillage: string) {
    return this.httpClient.get<any[]>(this.baseUrl + 'LandInVillageMaster/SelectlandInVillage/' + RevenueVillage);
  }
}
