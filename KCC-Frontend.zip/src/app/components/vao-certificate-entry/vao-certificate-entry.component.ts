import { Component, OnInit } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LookUp } from "src/app/services/LookUpService";
import { VAOCertificateEntry } from "src/app/services/VAOCerticateEntryService";
import { CertificateDetails } from "src/app/model/VAOCertificateEntryModel";

@Component({
  selector: 'app-vao-certificate-entry',
  templateUrl: './vao-certificate-entry.component.html',
  styleUrls: ['./vao-certificate-entry.component.css']
})
export class VaoCertificateEntryComponent implements OnInit {
  memberList: ComboModel[] = [];
  Acre: number = 0;
  LandInId: number = 0;
  RevenueId: number = 0;
  IrrigationId: number = 0;
  FirkaId: number = 0;
  OwnerId: number = 0;
  MemberId: number = 0;
  DOE: Date = new Date();
  CD: Date = new Date();
  LeaseEndDate:Date=new Date();

  OwnershipList: any = [];
  IrrigationList: any = [];
  FirkaList: any = [];
  RevenueVillageList: any = [];
  LandVillageList: any = [];
  certificateDetails: CertificateDetails[] = [];
  surveyno: number = 0;
  subdivision: string = "";
  totalarea: number = 0;
  bounded: number = 0;
  grandTotalArea: number = 0;
  grandTotalBounded: number = 0;
  constructor(private _apiService: APICall, private _lookUpService: LookUp, private _VAOCertificateEntry: VAOCertificateEntry) { }

  async ngOnInit() {
    this.GetMemberList();
    this.GetOwnership("OwnerShip");
    this.GetIrrigation("Irrigation");
    this.GetFirka();
  }
  GetMemberList() {
    this._apiService.BindAllMember().subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }
  GetOwnership(code: string) {
    this._lookUpService.GetLookUpList(code).subscribe((result: any[]) => {
      this.OwnershipList = result;
      console.log(this.OwnershipList);
    });
  }
  GetIrrigation(code: string) {
    this._lookUpService.GetLookUpList(code).subscribe((result: any[]) => {
      this.IrrigationList = result;
      console.log(this.OwnershipList);
    });
  }
  GetFirka() {
    this._VAOCertificateEntry.GetFirkaList().subscribe((result: any[]) => {
      this.FirkaList = result;
      console.log(this.OwnershipList);
    });
  }
  selectFirka(e: any) {
    this._VAOCertificateEntry.GetRevenueVillageList(e.target.value).subscribe((result: any[]) => {
      this.RevenueVillageList = result;
      console.log(this.RevenueVillageList);
    });
  }
  selectRevenueVillage(e: any) {
    this._VAOCertificateEntry.GetLandInVillageMasterList(e.target.value).subscribe((result: any[]) => {
      this.LandVillageList = result;
      console.log(this.LandVillageList);
    });
  }
  List() {

  }
  Save() {

  }
  Clear() {

  }
  Edit(id: number) {

  }
  Delete(id: number) {

  }

  Add() {
    let arr: CertificateDetails =
    {
      id: 0,
      surveyNo: this.surveyno,
      subDivision: this.subdivision,
      totalArea: this.totalarea,
      bounded: this.bounded,

    }
    this.certificateDetails.push(arr);

    this.grandTotalArea = 0;
    this.grandTotalBounded = 0;
    for (let i = 0; i < this.certificateDetails.length; i++) {
      this.grandTotalArea = Number(this.grandTotalArea) + Number(this.certificateDetails[i].totalArea);
      this.grandTotalBounded = Number(this.grandTotalBounded) + Number(this.certificateDetails[i].bounded);
    }
    this.clear();
  }

  clear() {
    this.surveyno=0;
    this.subdivision="";
    this.totalarea=0;
    this.bounded=0;
  }
}
