import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanSanctionModel, LoanSanctionDetails } from 'src/app/model/LoanSanctionModel';
import { DatePipe } from '@angular/common'
import { LoanSanctionListModel } from 'src/app/model/LoanSanctionListModel'
import { ValidationModel } from 'src/app/model/ValidationModel'
declare var $: any
@Component({
  providers: [DatePipe],
  selector: 'app-loan-sanction',
  templateUrl: './loan-sanction.component.html',
  styleUrls: ['./loan-sanction.component.css']
})
export class LoanSanctionComponent implements OnInit {
  loanTypList: ComboModel[] = [];
  memberList: ComboModel[] = [];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  aadhar: string = "";
  mobile: string = "";
  photoUrl: string = "";
  IsShowList: boolean = false;
  memberId: string = '0';
  SanctionDate: any = this.datepipe.transform(new Date(), 'dd-MM-yyyy');
  model: any;
  @Input() loanSanctionDetails: LoanSanctionDetails[] = [];
  Total: number = 0;
  GrandTotal: number = 0;
  sanctionAcre: number = 0;
  SanctionAmount: number = 0;
  ReqId: string = '0';
  loanTypeId: number = 0;
  LoanType: string = '';
  SanctionId: number = 0;
  EligibleAmount: number = 0;
  OutstandingAmount: number = 0;
  sanctionNo: number = 0;
  @Output() list: LoanSanctionListModel[] = [];

  constructor(public datepipe: DatePipe, private _apiService: APICall) { }

  ngOnInit() {
    this.GetMemberList();
    // this.GetRequesNos();
  }
  setLoanDetails(e: any) {
    this.ReqId = e.loanRequestId;
    this.loanTypeId = e.loanTypeID;
    this.memberId = e.memberID
    this.SanctionAmount = e.sanctionAmount;
    this.SanctionId = e.id;
    this.loanSanctionDetails = e.loanSanctionDetails;
    this.sanctionNo = e.sanctionNo;
    this.GetRequesNos();
  }
  DeleteRow(id: number) {
    var loan: any = this.loanSanctionDetails.find(a => { return a.id == id });

    this.SanctionAmount = Number(this.SanctionAmount) - Number(Number(loan.cash) +
      Number(loan.seed) + Number(loan.fertilizer) + Number(loan.pesticide) + Number(loan.kindSeed) + Number(loan.kindFertilizer) + Number(loan.kindPesticide));

    this.loanSanctionDetails.forEach((element, index) => {
      if (element.id == id) this.loanSanctionDetails.splice(index, 1);
    });
  }
  acreEnter(cacre: number, cropId: number, id: number, e: any) {
    if (Number(e.target.value) > cacre) {
      e.target.value = '0';
    }
    this._apiService.GetLoanRatioForCrop(cropId, Number(e.target.value)).subscribe((result: LoanSanctionDetails) => {
      let detail: any = this.loanSanctionDetails.find(a => { return a.id == id });
      detail.cash = result.cash;
      detail.seed = result.seed;
      detail.fertilizer = result.fertilizer;
      detail.pesticide = result.pesticide;
      detail.acreCash = result.acreCash;
      detail.kindSeed = result.kindSeed;
      detail.kindFertilizer = result.kindFertilizer;
      detail.kindPesticide = result.kindPesticide;
      detail.sanctionAcre = e.target.value;
      this.SanctionAmount = 0;
      for (let i = 0; i < this.loanSanctionDetails.length; i++) {
        this.SanctionAmount = Number(this.SanctionAmount) + Number(this.loanSanctionDetails[i].cash) +
          Number(this.loanSanctionDetails[i].seed) + Number(this.loanSanctionDetails[i].fertilizer) +
          Number(this.loanSanctionDetails[i].pesticide) + Number(this.loanSanctionDetails[i].kindSeed) + Number(this.loanSanctionDetails[i].kindFertilizer) + Number(this.loanSanctionDetails[i].kindPesticide);
      }
    });

  }
  List() {
    this.IsShowList = true;
    this.GetLoanList();
  }
  Clear() {
    this.memberId = '0';
    this.ReqId = '0';
    this.LoanType = '';
    this.loanSanctionDetails = [];
    this.SanctionAmount = 0;
    this.SanctionId = 0;
    this.memberName = '';
    this.memberAdd1 = '';
    this.memberAdd2 = '';
    this.memberAdd3 = '';
    this.aadhar = '';
    this.mobile = '';
    this.photoUrl = '';
    this.OutstandingAmount = 0;
  }
  GetLoanList() {
    this._apiService.BindLoanSanctionList(1).subscribe((result: LoanSanctionListModel[]) => {
      this.list = result;
    });
  }
  Save() {
    debugger;
    this.loanSanctionDetails.forEach(a => { a.id = 0 });
    var model: LoanSanctionModel =
    {
      loanRequestId: Number(this.ReqId),
      loanTypeID: Number(this.loanTypeId),
      pacsId: 1,
      fYearId: 1,
      sanctionNo: this.sanctionNo,
      sanctionDate: new Date(),
      memberID: Number(this.memberId),
      sanctionAmount: this.SanctionAmount,
      loanSanctionDetails: this.loanSanctionDetails,
      id: this.SanctionId
    }
    debugger;
    this._apiService.LoanSanctionValidation(model).subscribe((result: ValidationModel) => {
      if (result.isValid) {
        this.SaveSanction(model);

      }
      else if (result.warningMessage != '') {
        if (confirm(result.warningMessage)) {

          this.SaveSanction(model);
        }
        else if (result.validationMessage != '') {
          alert(result.validationMessage);
        }
      }
      else {
        alert(result.validationMessage);
      }
    });
  }

  SaveSanction(model: LoanSanctionModel) {
    debugger;
    if (this.SanctionId == 0) {
      this._apiService.SaveLoanSanction(model).subscribe((result: any) => {
        if (result) {
          alert('success');
          this.Clear();
        }
        else {
          alert('failed to save')
        }
      });
    }
    else {

      this._apiService.UpdateLoanSanction(this.SanctionId, model).subscribe((result: any) => {
        if (result) {
          alert('success');
          this.Clear();
        }
        else {
          alert('failed to save')
        }
      });
    }
  }
  selectedRequest(e: any) {
    this.loanSanctionDetails = [];
    let id: number = e.target.value;
    this._apiService.GetRequestById(id).subscribe((result: any) => {
      if (result != null) {
        this.model = result;
        this.loanSanctionDetails = this.model.loanSanctionDetails;
        this.SanctionAmount = 0;
        this.loanTypeId = result.loanTypeID;
        this._apiService.BindLoanType().subscribe((result: ComboModel[]) => {
          let loan: any = result.find(a => { return a.value == this.loanTypeId.toString() });
          this.LoanType = loan.text;
        });
        for (let i = 0; i < this.loanSanctionDetails.length; i++) {
          this.SanctionAmount = Number(this.SanctionAmount) + Number(this.loanSanctionDetails[i].cash) +
            Number(this.loanSanctionDetails[i].seed) + Number(this.loanSanctionDetails[i].fertilizer) +
            Number(this.loanSanctionDetails[i].pesticide) + Number(this.loanSanctionDetails[i].kindSeed) + Number(this.loanSanctionDetails[i].kindFertilizer) + Number(this.loanSanctionDetails[i].kindPesticide);
        }
        if (this.LoanType != "JLG") {
          this._apiService.GetMaxLimitByLoanType(this.loanTypeId).subscribe((result: number) => {

            this.EligibleAmount = Number(result - this.OutstandingAmount);
            if (this.EligibleAmount <= Number(result)) {
              this.EligibleAmount = this.EligibleAmount;
            }
            else {
              this.EligibleAmount = result;
            }
          });
        }
      }

    });

  }
  selected(e: any) {
    let id: number = e.target.value;
    this.memberId = id.toString();
    this.GetRequesNos();
    this._apiService.GetMemberInfo(id).subscribe((result: any) => {
      if (result != null) {
        this.memberName = result.name;
        this.memberAdd1 = result.address1;
        this.memberAdd2 = result.address2;
        this.memberAdd3 = result.address3;
        this.aadhar = result.adhaarNumber;
        this.mobile = result.mobileNumber;
        this.photoUrl = result.photoUrl;
        this.OutstandingAmount = result.outstandingAmount;
      }
      else {
        this.memberName = '';
        this.memberAdd1 = '';
        this.memberAdd2 = '';
        this.memberAdd3 = '';
        this.aadhar = '';
        this.mobile = '';
        this.photoUrl = '';
        this.OutstandingAmount = 0;
      }
    });

  }
  GetRequesNos() {
    this._apiService.GetRequestNos(Number(this.memberId)).subscribe((result: ComboModel[]) => {
      this.loanTypList = result;
      console.log(this.loanTypList);
    });
  }
  GetMemberList() {
    this._apiService.BindAllMember().subscribe((result: ComboModel[]) => {
      this.memberList = result;
      setTimeout(() => {
        $('.selectpicker').selectpicker('refresh');
      }, 500);
      console.log(this.memberList);
    });
  }

}
