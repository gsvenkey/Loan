import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-capital-type',
  templateUrl: './capital-type.component.html',
  styleUrls: ['./capital-type.component.css']
})
export class CapitalTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
