import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { CropDetails } from 'src/app/model/CropDetails';
import { analyzeAndValidateNgModules } from '@angular/compiler';
declare var $: any;
@Component({
  selector: 'app-crop-details',
  templateUrl: './crop-details.component.html',
  styleUrls: ['./crop-details.component.css']
})
export class CropDetailsComponent implements OnChanges {
  vaoDetailId: string = "";
  cropList: ComboModel[] = [];
  categoryList: ComboModel[] = [];
  totalAcre: number = 0;
  surveyDetails: any;
  @Input() memberId: number = 0;
  @Input() loanType: string = "";
  category: string = "";
  crop: string = "";
  survey: string = "";
  acre: number = 0;
  cropId: string = "";
  @Input() cropDetails: CropDetails[] = [];
  duePeriod: number = 0;
  @Output() getCropDetails = new EventEmitter<CropDetails[]>();
  loanDuePeriod: number = 0;
  requestAmount: number = 0;
  estimateAmount: number = 0;
  estimateAcre: number = 0;
  CategoryId: string = '0';
  constructor(private _apiService: APICall) { }

  ngOnChanges() {
    this.GetSurveyDetails();
    this.GetCategoryList();
    this.UpdateCrop();
  }
  periodEnter() {
    // this._apiService.GetCropPeriod(1, this.cropId).subscribe((result: number) => {
    //   this.duePeriod = result;
    //   this.loanDuePeriod = this.duePeriod + this.loanDuePeriod;
    // });
    if (this.cropDetails.length != 0) {
      let period: number = this.cropDetails[0].duePeriod;
      if (period != this.duePeriod) {
        alert("Due Period should be equal in all the items.")
        this.duePeriod = 0;
      }
    }
  }
  acreEnter(e: any) {
    this.acre = e.target.value;
    if (e.target.value > this.totalAcre) {
      this.acre = 0;
      e.target.value = '0';
      return;
    }
    if (this.cropDetails.length != 0) {
      let crops: CropDetails[] = [];
      this.cropDetails.forEach(a => { if (a.surveyNo.trim() == $('#survey option:selected').text().trim()) { crops.push(a) } });
      let totalsurveyacre: number = 0;
      crops.forEach(element => {
        totalsurveyacre = Number(totalsurveyacre) + Number(element.acre);
      });
      totalsurveyacre = Number(totalsurveyacre) + Number(this.acre);
      if (totalsurveyacre > this.totalAcre) {
        this.acre = 0;
        e.target.value = '0';
        alert("Acre exceed");
      }
    }
    this._apiService.GetLoanEstimationAmount(Number(this.cropId), this.acre).subscribe((result: number) => {
      this.estimateAmount = result;
    });
  }

  selectedSurvey(e: any) {
    this.totalAcre = $(e.target).find('option:selected').data('acre');
    this.vaoDetailId = $(e.target).find('option:selected').data('vaodetailid');

    this.survey = $(e.target).find('option:selected').text();
  }
  GetSurveyDetails() {
    //let id=Number(this.cookie.get("MemberId"));
    if (this.loanType == "JLG") {
      this._apiService.GetJLGSurveyDetails(this.memberId).subscribe((result: any) => {
        debugger;
        this.surveyDetails = result;
        console.log(this.surveyDetails);
      });
    } else {
      this._apiService.GetSurveyDetails(this.memberId).subscribe((result: any) => {
        debugger;
        this.surveyDetails = result;
        console.log(this.surveyDetails);
      });
    }
  }
  UpdateCrop() {
    if (this.cropDetails.length != 0 && this.cropDetails != undefined) {
      this.cropDetails.forEach(a => {
        this._apiService.GetLoanEstimationAmount(Number(a.cropId), a.acre).subscribe((result: number) => {
          a.estimateAmount = result;
        });

      });

      // this.getCropDetails.emit(this.cropDetails);
      this.requestAmount = this.cropDetails[0].requestAmount;
      this.cropDetails.forEach(a => { a.requestAmount = this.requestAmount });
      this.estimateAcre = 0;
      for (let i = 0; i < this.cropDetails.length; i++) {
        this.estimateAcre = Number(this.estimateAcre) + Number(this.cropDetails[i].acre);
      }
    }
    else {
      this.requestAmount = 0;
      this.estimateAcre = 0;
    }
  }
  DeleteRow(crop: string, survey: string) {
    this.cropDetails.forEach((element, index) => {
      if (element.cropName == crop && element.surveyNo == survey) this.cropDetails.splice(index, 1);
    });

    this.requestAmount = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.requestAmount = Number(this.requestAmount) + Number(this.cropDetails[i].estimateAmount);
    }
    this.cropDetails.forEach(a => { a.requestAmount = this.requestAmount });

    this.estimateAcre = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.estimateAcre = Number(this.estimateAcre) + Number(this.cropDetails[i].acre);
    }
  }
  AddCrop() {
    debugger;
    let arr: CropDetails =
    {
      id: 0,
      cropCategoryName: this.category,
      acre: Number(this.acre),
      cropName: this.crop,
      cropId: this.cropId,
      cropCategoryId: Number(this.CategoryId),
      vaoDetailId: this.vaoDetailId,
      surveyNo: this.survey.trim(),
      cultivationAcre: this.totalAcre,
      duePeriod: this.duePeriod,
      requestAmount: this.requestAmount,
      estimateAmount: this.estimateAmount,
      loanDuePeriod: this.duePeriod,
      vaoDetail: null
    }
    this.cropDetails.push(arr);

    this.getCropDetails.emit(this.cropDetails);

    this.cropDetails = this.cropDetails.reduce((accumalator: CropDetails[], current) => {
      if (!accumalator.some(item => item.cropId === current.cropId)) {
        accumalator.push(current);
      }
      return accumalator;
    }, []);

    this.requestAmount = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.requestAmount = Number(this.requestAmount) + Number(this.cropDetails[i].estimateAmount);
    }
    this.cropDetails.forEach(a => { a.requestAmount = this.requestAmount });

    this.estimateAcre = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.estimateAcre = Number(this.estimateAcre) + Number(this.cropDetails[i].acre);
    }

    this.ClearRow();
  }

  EditRow(cropCategoryId: number, cropId: string, vaoDetailId: string) {
    this.CategoryId = cropCategoryId.toString();
    this.cropId = cropId;
    this.vaoDetailId = vaoDetailId.toString();

    this.cropDetails.forEach((element, index) => {
      if (element.cropCategoryId == cropCategoryId && element.cropId == cropId) this.cropDetails.splice(index, 1);
    });


    this.requestAmount = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.requestAmount = Number(this.requestAmount) + Number(this.cropDetails[i].estimateAmount);
    }
    this.cropDetails.forEach(a => { a.requestAmount = this.requestAmount });

    this.estimateAcre = 0;
    for (let i = 0; i < this.cropDetails.length; i++) {
      this.estimateAcre = Number(this.estimateAcre) + Number(this.cropDetails[i].acre);
    }
  }

  ClearRow() {
    this.CategoryId = "";
    this.cropId = "";
    this.vaoDetailId = "";
    this.category = "";
    this.acre = 0;
    this.crop = '';
    this.survey = '0';
    this.totalAcre = 0;
    this.duePeriod = 0;
    this.estimateAmount = 0;
    $('#survey').val('0');
    $('#crop').val('0');
    $('#category').val('0');
    this.CategoryId = '0'
  }
  GetCategoryList() {
    this._apiService.BindCropCategoryList().subscribe((result: ComboModel[]) => {
      this.categoryList = result;
      console.log(this.cropList);
    });
  }
  selectedCategory(e: any) {
    debugger;
    let id: number = e.target.value;
    this.category = $(e.target).find('option:selected').text();
    this._apiService.BindCropListByCategory(id).subscribe((result: ComboModel[]) => {
      this.cropList = result;
      console.log(this.cropList);
    });
  }
  // editCategory(){
  //   debugger;
  //   //let id: number = e.target.value;
  //   //this.category = $(e.target).find('option:selected').text();
  //   this._apiService.BindCropListByCategory(Number(this.CategoryId)).subscribe((result: ComboModel[]) => {
  //     this.cropList = result;
  //     console.log(this.cropList);
  //   });
  // }
  selected(e: any) {
    this.cropId = e.target.value;
    this.crop = $(e.target).find('option:selected').text();
    this._apiService.GetCropPeriod(Number(this.cropId)).subscribe((result: number) => {
      this.duePeriod = result;
      // this.loanDuePeriod = this.duePeriod + this.loanDuePeriod;
    });
  }

}
