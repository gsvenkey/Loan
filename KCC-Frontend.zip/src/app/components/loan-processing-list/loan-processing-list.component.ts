import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { LoanListModel } from 'src/app/model/LoanListModel';
import { LoanRequestModel } from 'src/app/model/LoanRequestModel';

@Component({
  selector: 'app-loan-processing-list',
  templateUrl: './loan-processing-list.component.html',
  styleUrls: ['./loan-processing-list.component.css']
})
export class LoanProcessingListComponent implements OnInit {
  @Input() refresh: boolean = true;
  @Output() getLoanDetails = new EventEmitter<LoanRequestModel>();
  @Input() loanList: LoanListModel[] = [];
  constructor(private _apiService: APICall) { }

  ngOnInit() {
    //this.GetLoanList();
  }
  GetLoanList() {
    this._apiService.BindLoanList(1).subscribe((result: LoanListModel[]) => {
      if (result != null) {
        this.loanList = result;
        console.log(this.loanList);
      }
    });
  }
  Edit(id: number) {
    this._apiService.GetLoanDetails(id).subscribe((result: LoanRequestModel) => {
      debugger;
      this.getLoanDetails.emit(result);
    });
  }
  Delete(id: number) {
    if (confirm('Are you sure want to delete this item?')) {
      this._apiService.DeleteLoanRequest(id).subscribe((result: boolean) => {
        if (result) {
          alert("success");
          this.GetLoanList();
        }
        else {
          alert("failure")
        }
      });

    } else {
      // Do nothing!
      console.log('Thing was not saved to the database.');
    }

  }
}
