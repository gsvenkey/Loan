import { Component, OnInit, ViewChild, AfterContentInit } from '@angular/core';
import { FormGroup, RequiredValidator } from '@angular/forms'
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanRequestModel } from 'src/app/model/LoanRequestModel';
import { CropDetails } from 'src/app/model/CropDetails';
import { SuretyDetails } from 'src/app/model/SuretyDetails';
import { JLGTypeModel } from 'src/app/model/JLGTypeModel';
import { JLGLoanMemberModel } from 'src/app/model/JLGLoanMemberModel';
import { TieupModel } from 'src/app/model/TieupModel';
import { JewelDetails } from 'src/app/model/JewelDetails';
import { LandTypeModel } from 'src/app/model/LandTypeModel';
import { LoanListModel } from 'src/app/model/LoanListModel';
import { ValidationModel } from 'src/app/model/ValidationModel';


declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loanTypList: ComboModel[] = [];
  memberId: number = 0;
  loanType: string = '';
  suretyDetails: SuretyDetails[] = [];;
  loanTypeId: number = 0;
  cropDetails: CropDetails[] = [];
  JLGDetails: JLGTypeModel[] = [];
  JLGMembers: JLGLoanMemberModel[] = [];
  TieupDetails: TieupModel[] = [];
  JewelDetails: JewelDetails[] = [];
  LandPledgeDetails: LandTypeModel[] = [];
  IsShowList: boolean = false;
  Adangal: boolean = true;
  PasaliYear: number = 0;
  loanRequestModel: any;
  requestNo: number = 0;
  loanList: LoanListModel[] = [];
  Id: number = 0;

  constructor(private _apiService: APICall) { }

  ngOnInit() {
    this.GetLoanTypes();
  }

  List() {
    this.IsShowList = true;
    this._apiService.BindLoanList(1).subscribe((result: LoanListModel[]) => {
      if (result != null) {
        this.loanList = result;
        console.log(this.loanList);
      }
    });
  }
  setLoanDetails(e: any) {
    debugger;
    this.loanRequestModel = e;
    this.Id = this.loanRequestModel.id;
    this.requestNo = this.loanRequestModel.requestNo;
    this.memberId = this.loanRequestModel.memberID;
    this.loanTypeId = this.loanRequestModel.loanTypeID;
    this.JewelDetails = this.loanRequestModel.jewelPledgedDetails;
    this.JLGDetails = this.loanRequestModel.jlgLoanTypeDetails;
    this.JLGMembers = this.loanRequestModel.jlgLoanMemberDetails;
    this.LandPledgeDetails = this.loanRequestModel.landPledgedDetails
    this.suretyDetails = this.loanRequestModel.suretyDetails;
    this.TieupDetails = this.loanRequestModel.tieUpCompanyDetails;
    //this.cropDetails = this.loanRequestModel.loanRequestDetails;
    var loan: any = this.loanTypList.find(a => { return a.value == this.loanTypeId.toString() });
    this.loanType = loan.text;
    this.Adangal = this.loanRequestModel.isAdangal;
    this.PasaliYear = this.loanRequestModel.pasalaiYear;
    let updatedcrop: CropDetails[] = this.loanRequestModel.loanRequestDetails;
    this.cropDetails = [];
    updatedcrop.forEach(a => {

      let arr: CropDetails =
      {
        id: a.id,
        cropCategoryName: a.cropCategoryName,
        acre: Number(a.acre),
        cropName: a.cropName,
        cropId: a.cropId,
        cropCategoryId: Number(a.cropCategoryId),
        vaoDetailId: a.vaoDetailId,
        surveyNo: a.vaoDetail.serveyNo,
        cultivationAcre: a.cultivationAcre,
        duePeriod: a.loanDuePeriod,
        requestAmount: a.requestAmount,
        estimateAmount: a.estimateAmount,
        loanDuePeriod: a.loanDuePeriod,
        vaoDetail: a.vaoDetail
      }
      this.cropDetails.push(arr);
    })
  }
  Clear() {
    this.memberId = 0;
    this.loanTypeId = 0;
    this.suretyDetails = [];
    this.cropDetails = [];
    this.loanType = '';
    this.PasaliYear = 0;
    this.Adangal = false;
  }
  GetLoanTypes() {
    this._apiService.BindLoanType().subscribe((result: ComboModel[]) => {
      this.loanTypList = result;
      console.log(this.loanTypList);
    });
  }
  selected(e: any) {
    this.loanType = e.target.value;
    this.loanTypeId = $(e.target).find('option:selected').data('type');
  }
  setJewelDetails(e: any) {
    this.JewelDetails = e;
  }
  setLandDetails(e: any) {
    this.LandPledgeDetails = e;
  }
  setTieupDetails(e: any) {
    this.TieupDetails = e;
  }
  surveydetailsInvoke(e: any) {
    this.memberId = e;
  }
  setSuretyDetails(e: any) {
    this.suretyDetails = e;
  }
  setCropDetails(e: any) {
    this.cropDetails = e;
  }
  setJLGDetails(e: any) {
    this.JLGDetails = e;
  }
  setJLGMember(e: any) {
    this.JLGMembers = e;
  }
  setLoanType(e: any) {
    this.loanType = e;
  }
  setLoanTypeId(e: any) {
    this.loanTypeId = e;
  }
  setAdangal(e: any) {
    this.Adangal = e;
  }
  setPasali(e: any) {
    this.PasaliYear = e;
  }
  Save() {
    let model: LoanRequestModel =
    {
      id: this.Id,
      createdDate: new Date(),
      fYearId: 1,
      loanTypeID: this.loanTypeId,
      memberID: this.memberId,
      pacsId: 1,
      requestDate: new Date(),
      requestNo: this.requestNo,
      isAdangal: this.Adangal,
      pasalaiYear: this.PasaliYear,
      requestAmount: this.cropDetails[0].requestAmount,
      loanRequestDetails: this.cropDetails,
      //vaoCertificateHeaderId: 4,
      suretyDetails: this.suretyDetails,
      jlgLoanTypeDetails: this.JLGDetails,
      jlgLoanMemberDetails: this.JLGMembers,
      tieUpCompanyDetails: this.TieupDetails,
      jewelPledgedDetails: this.JewelDetails,
      landPledgedDetails: this.LandPledgeDetails
    };

    this._apiService.LoanRequestValidation(model).subscribe((result: ValidationModel) => {
      if (result.isValid) {
        this.SaveRequest(model);
      }
      else if (result.warningMessage != '') {
        if (confirm(result.warningMessage)) {

          this.SaveRequest(model);
        }
        else if (result.validationMessage != '') {
          alert(result.validationMessage);
        }
      } else {
        alert(result.validationMessage);
      }
    });
  }

  SaveRequest(model: LoanRequestModel) {
    if (this.Id == 0) {
      this._apiService.SaveLoanRequest(model).subscribe((result: boolean) => {
        if (result) {
          alert('success');
          this.Clear();
        }
        else {
          alert('failed to save')
        }
      });
    }
    else {
      this._apiService.UpdateLoanRequest(this.requestNo, model).subscribe((result: boolean) => {
        if (result) {
          alert('success');
          this.Clear();
        }
        else {
          alert('failed to save')
        }
      });
    }
  }
}
