import { Component, OnInit, Output, EventEmitter, Input, SimpleChanges } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { DatePipe } from '@angular/common'
declare var $: any;

@Component({
  providers: [DatePipe],
  selector: 'app-member-details',
  templateUrl: './member-details.component.html',
  styleUrls: ['./member-details.component.css']
})
export class MemberDetailsComponent implements OnInit {
  loanTypList: ComboModel[] = [];
  memberList: ComboModel[] = [];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  aadhar: string = "";
  mobile: string = "";
  photoUrl: string = "";
  @Input() loanType: string = '';
  @Input() loanTypeId: number = 0;
  RequestDate: any = this.datepipe.transform(new Date(), 'dd-MM-yyyy');
  @Input() Adangal: boolean = false;
  @Input() Pasali: number = 0;
  @Input() memberId: number = 0;

  @Output() getMemberChange = new EventEmitter<number>();
  @Output() getLoanTypeChange = new EventEmitter<string>();
  @Output() getLoanTypeIdChange = new EventEmitter<number>();
  @Output() getAdangalChange = new EventEmitter<boolean>();
  @Output() getPasaliYear = new EventEmitter<number>();
  EligibleAmount: string = "0.00";
  OutstandingAmount: string = "0.00";
  constructor(public datepipe: DatePipe, private _apiService: APICall) { }

  ngOnInit() {
    this.GetMemberList();
    this.GetLoanTypes();
    this.selected();

  }

  ngAfterViewInit() {
    //$('.selectpicker').selectpicker('refresh');
    // setTimeout(() => {
    //   $('.selectpicker').selectpicker('refresh');
    // }, 500);
  }

  PasaliKeyup() {
    this.getPasaliYear.emit(this.Pasali)
    let month: number = new Date().getMonth();
    let year: number = new Date().getFullYear();
    if (month <= 6) {
      //this.Pasali = Number(year) - Number(591);
      console.log(Number(year) - Number(591));
      if (this.Pasali != Number(year) - Number(591)) {
        this.Pasali = 0;
        alert('Enter correct pasali year!!!');
      }
    }
    else {
      console.log(Number(Number(year) - Number(591)) + Number(1));
      if (this.Pasali != Number(Number(year) - Number(591)) + Number(1)) {
        this.Pasali = 0;
        alert('Enter correct pasali year!!!');
      }
    }
  }
  GetLoanTypes() {
    this._apiService.BindLoanType().subscribe((result: ComboModel[]) => {
      this.loanTypList = result;
      console.log(this.loanTypList);
    });
  }
  GetMemberList() {
    this._apiService.BindMember().subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
      setTimeout(() => {
        $('.selectpicker').selectpicker('refresh');
      }, 500);
    });
  }
  GetJlgMemberList() {
    this._apiService.BindJlgMember().subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
      setTimeout(() => {
        $('.selectpicker').selectpicker('refresh');
      }, 500);
    });
  }
  selected() {
    //debugger;
    this.getMemberChange.emit(this.memberId)
    if (this.memberId > 0) {
      this._apiService.GetMemberInfo(this.memberId).subscribe((result: any) => {
        if (result != null) {
          this.memberName = result.name;
          this.memberAdd1 = result.address1;
          this.memberAdd2 = result.address2;
          this.memberAdd3 = result.address3;
          this.aadhar = result.adhaarNumber;
          this.mobile = result.mobileNumber;
          this.photoUrl = result.photoUrl;
          this.OutstandingAmount = result.outstandingAmount;
          if (this.loanType != "JLG") {
            this._apiService.GetMaxLimitByLoanType(this.loanTypeId).subscribe((result: number) => {

              this.EligibleAmount = (result - Number(this.OutstandingAmount)).toString();
              if (Number(this.EligibleAmount) <= Number(result)) {
                this.EligibleAmount = Number(this.EligibleAmount).toFixed(2).toString();
              }
              else {
                this.EligibleAmount = result.toFixed(2);
              }
            });
          }
        }
        else {
          this.memberName = '';
          this.memberAdd1 = '';
          this.memberAdd2 = '';
          this.memberAdd3 = '';
          this.aadhar = '';
          this.mobile = '';
          this.photoUrl = '';
          this.OutstandingAmount = "0.00";
          this.EligibleAmount = "0.00";
        }
      });
    }
  }
  selectedLoan(e: any) {
    this.loanType = $(e.target).find('option:selected').data('type');
    this.loanTypeId = e.target.value;
    this.getLoanTypeChange.emit(this.loanType);
    this.getLoanTypeIdChange.emit(this.loanTypeId);
    if (this.loanType == "JLG") {
      this.GetJlgMemberList();
    } else {
      this.GetMemberList();
    }
  }
  // ngOnChanges(changes: SimpleChanges) {
  // }
}
