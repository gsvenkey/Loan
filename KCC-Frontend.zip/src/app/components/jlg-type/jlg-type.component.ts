import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { JLGTypeModel } from 'src/app/model/JLGTypeModel';
import { JLGLoanMemberModel } from 'src/app/model/JLGLoanMemberModel';



@Component({
  selector: 'app-jlg-type',
  templateUrl: './jlg-type.component.html',
  styleUrls: ['./jlg-type.component.css']
})
export class JlgTypeComponent implements OnInit {
  @Input() memberId: number = 0;
  memberList: ComboModel[] = [];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  mobile: string = "";
  photoUrl: string = "";
  RD: Date = new Date();
  II: number = 0;
  SA: number = 0;
  MSA: number = 0;
  JLGCB: number = 0;
  LOA: number = 0;
  SABA: number = 0;
  ODLA: number = 0;
  jlgMemberList: any=[];
  @Input() JLGMembers: JLGLoanMemberModel[] = [];
  @Input() JLGTypeModel: JLGTypeModel[] = [];
  @Output() getModel = new EventEmitter<JLGTypeModel[]>();
  @Output() getJLGMember = new EventEmitter<JLGLoanMemberModel[]>();

  constructor(private _apiService: APICall) { }

  ngOnInit(): void {
    debugger;
    this.GetMemberList();
    this.UpdateJLG();
  }
  UpdateJLG() {
    this.JLGTypeModel.forEach(a => {
      this.SABA = a.balanceAmount;
      this.SA = a.govtRFSubsidyAmount;
      this.II = a.interestIncome;
      this.JLGCB = a.jlgCashBalance;
      this.LOA = a.loanOutstanding;
      this.SA = a.memberSavingsAmount;
      this.ODLA = a.membersODLoanAmount;
      this.RD = a.resolutionDate;
    });
  }
  DeleteRow(id: number) {
    this.JLGMembers.forEach((element, index) => {
      if (element.memberId == id) this.JLGMembers.splice(index, 1);
    });
  }

  GetMemberList() {
    debugger;
    let id: number = this.memberId;
    this._apiService.GetJLGMemeberInfo(id).subscribe((result: any) => {
      this.jlgMemberList=result;
      // var arr: JLGLoanMemberModel = {
      //   name: result.name,
      //   AadharNo: result.aadharNo,
      //   mobileNo: result.mobileNumber,
      //   memberId: id,
      //   modifiedDate: new Date(),
      //   modifiedBy: 1,
      //   message: '',
      //   loanRequestId: 1,
      //   isDeleted: false,
      //   createdDate: new Date(),
      //   createdBy: 1,
      //   id: 0,
      //   photoUrl: result.photoUrl
      // }
      //this.JLGMembers.push(arr);
      //this.getJLGMember.emit(this.JLGMembers);
    });
  }
  // selected(e: any) {
  //   let id: number = e.target.value;
  //   this.memberId = id;
  //   this._apiService.GetMemberInfo(id).subscribe((result: any) => {
  //     var arr: JLGLoanMemberModel = {
  //       name: result.name,
  //       AadharNo: result.aadharNo,
  //       mobileNo: result.mobileNumber,
  //       memberId: id,
  //       modifiedDate: new Date(),
  //       modifiedBy: 1,
  //       message: '',
  //       loanRequestId: 1,
  //       isDeleted: false,
  //       createdDate: new Date(),
  //       createdBy: 1,
  //       id: 0,
  //       photoUrl: result.photoUrl
  //     }
  //     this.JLGMembers.push(arr);
  //     this.getJLGMember.emit(this.JLGMembers);
  //   });
  // }

  ModelBinding() {
    var model: JLGTypeModel = {
      createdBy: 1,
      balanceAmount: this.SABA,
      createdDate: new Date(),
      govtRFSubsidyAmount: this.SA,
      id: 0,
      interestIncome: this.II,
      isDeleted: false,
      jlgCashBalance: this.JLGCB,
      loanOutstanding: this.LOA,
      loanRequestId: 1,
      memberId: this.memberId,
      memberSavingsAmount: this.SA,
      membersODLoanAmount: this.ODLA,
      message: "",
      modifiedBy: 1,
      modifiedDate: new Date(),
      resolutionDate: this.RD,
      resolutionNumber: 0
    }
    var arr: JLGTypeModel[] = [];
    arr.push(model);
    this.getModel.emit(arr);
  }
}
