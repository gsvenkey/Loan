import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ComboModel } from 'src/app/model/ComboModel';
import { LandTypeModel } from 'src/app/model/LandTypeModel';
import { APICall } from 'src/app/services/APICall.Services';

@Component({
  selector: 'app-land-type',
  templateUrl: './land-type.component.html',
  styleUrls: ['./land-type.component.css']
})
export class LandTypeComponent implements OnInit {
  @Input() landDetails: LandTypeModel[] = [];
  subdistrictList: ComboModel[] = [];
  subRegOfficeList: ComboModel[] = [];
  DOM: Date = new Date();
  MRN: string = '';
  MA: number = 0;
  SRO: string = '0';
  SRD: string = '0';
  @Output() getModel = new EventEmitter<LandTypeModel[]>();

  constructor(private _apiService: APICall) { }

  ngOnInit() {
    this.GetSubDistrictList();
    this.UpdateDetails();
  }
  UpdateDetails() {
    this.landDetails.forEach(a => {
      this.DOM = a.dateOfMortgage;
      this.MA = a.mortgageAmount;
      this.MRN = a.mortgageRegNo;
      this.SRO = a.subRegisterId.toString();
    });
  }
  GetSubDistrictList() {
    this._apiService.BindSubRegDistrict().subscribe((result: ComboModel[]) => {
      this.subdistrictList = result;
      console.log(this.subdistrictList);
    });
  }
  SetModel() {
    if (this.SRO == "0") {
      this._apiService.BindSubRegOffice(Number(this.SRD)).subscribe((result: ComboModel[]) => {
        this.subRegOfficeList = result;
        console.log(this.subdistrictList);
      });
    }
    this.landDetails = [];
    var arr: LandTypeModel =
    {
      modifiedDate: new Date(),
      modifiedBy: 1,
      message: '',
      loanRequestId: 1,
      isDeleted: false,
      createdDate: new Date(),
      createdBy: 1,
      id: 0,
      dateOfMortgage: this.DOM,
      mortgageAmount: this.MA,
      mortgageRegNo: this.MRN,
      subRegisterId: Number(this.SRO)
    }
    this.landDetails.push(arr);
    this.getModel.emit(this.landDetails);
  }
}
