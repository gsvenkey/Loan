import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ComboModel } from 'src/app/model/ComboModel';
import {TieupModel} from 'src/app/model/TieupModel';
import {APICall} from 'src/app/services/APICall.Services';
import {TieupCompanyModel} from 'src/app/model/TieupCompanyModel'

@Component({
  selector: 'app-tieup-type',
  templateUrl: './tieup-type.component.html',
  styleUrls: ['./tieup-type.component.css']
})
export class TieupTypeComponent implements OnInit {
  TieupDetails:TieupModel[]=[];
TCN:string='0';
TLD:Date = new Date();
MLA:number=0
@Output() getModel = new EventEmitter<TieupModel[]>();
TieupCompanyList:ComboModel[]=[]
companyAddress:string='';
contactNo:number=0;
  constructor(private _apiService:APICall) { }

  ngOnInit() {
    this.GetTieupCompanyList();
  }
  GetTieupCompanyList()
  {
    this._apiService.BindTieupCompanyList(1).subscribe((result:ComboModel[]) => {
      this.TieupCompanyList=result;
      console.log(this.TieupCompanyList);
    });
  }
  setModel()
  {
    this._apiService.GetTieupCompanyDetailsById(Number(this.TCN)).subscribe((result:TieupCompanyModel) => {
      if(result!=null)
      {
      this.companyAddress=result.companyAddress;
      this.contactNo=result.contactNo;
      }
    });
    this.TieupDetails=[];
    var arr:TieupModel=
    {
      modifiedDate:new Date(),
      modifiedBy:1,
      message:'',
      loanRequestId:1,
      isDeleted:false,
      createdDate:new Date(),
      createdBy:1,
      id:1,
      maximumLoanAmount:this.MLA,
      tieUpCompanyId:Number(this.TCN),
      tieupLetterDate:this.TLD
    }
    this.TieupDetails.push(arr);
    this.getModel.emit(this.TieupDetails);
  }

}
