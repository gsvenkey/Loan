import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanSanctionModel, LoanSanctionDetails } from 'src/app/model/LoanSanctionModel';

@Component({
  selector: 'app-loan-sanction',
  templateUrl: './loan-sanction.component.html',
  styleUrls: ['./loan-sanction.component.css']
})
export class LoanSanctionComponent implements OnInit {
  loanTypList: ComboModel[] = [];
  memberList: ComboModel[] = [];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  aadhar: string = "";
  mobile: string = "";
  photoUrl: string = "";
  IsShowList: boolean = false;
  memberId: string = '0';
  SanctionDate: String = new Date().toDateString();
  model: any;
  loanSanctionDetails: LoanSanctionDetails[] = [];
  Total: number = 0;
  GrandTotal: number = 0;
  sanctionAcre: number = 0;
  SanctionAmount: number = 0;
  ReqId: string = '0';
  loanTypeId: number = 0;
  constructor(private _apiService: APICall) { }

  ngOnInit() {
    this.GetMemberList();
    this.GetRequesNos();
  }
  DeleteRow(id: number) {
    var loan: any = this.loanSanctionDetails.find(a => { return a.id == id });

    this.SanctionAmount = Number(this.SanctionAmount) - Number(Number(loan.cash) +
      Number(loan.seed) + Number(loan.fertilizer) + Number(loan.pesticide) + Number(loan.kindSeed) + Number(loan.kindFertilizer) + Number(loan.kindPesticide));

    this.loanSanctionDetails.forEach((element, index) => {
      if (element.id == id) this.loanSanctionDetails.splice(index, 1);
    });
  }
  acreEnter(cacre: number, cropId: number, id: number, e: any) {
    if (Number(e.target.value) > cacre) {
      e.target.value = '0';
    }
    this._apiService.GetLoanRatioForCrop(1, cropId, Number(e.target.value)).subscribe((result: LoanSanctionDetails) => {
      let detail: any = this.loanSanctionDetails.find(a => { return a.id == id });
      detail.cash = result.cash;
      detail.seed = result.seed;
      detail.fertilizer = result.fertilizer;
      detail.pesticide = result.pesticide;
      detail.acreCash = result.acreCash;
      detail.kindSeed = result.kindSeed;
      detail.kindFertilizer = result.kindFertilizer;
      detail.kindPesticide = result.kindPesticide;
      this.SanctionAmount = 0;
      for (let i = 0; i < this.loanSanctionDetails.length; i++) {
        this.SanctionAmount = Number(this.SanctionAmount) + Number(this.loanSanctionDetails[i].cash) +
          Number(this.loanSanctionDetails[i].seed) + Number(this.loanSanctionDetails[i].fertilizer) +
          Number(this.loanSanctionDetails[i].pesticide) + Number(this.loanSanctionDetails[i].kindSeed) + Number(this.loanSanctionDetails[i].kindFertilizer) + Number(this.loanSanctionDetails[i].kindPesticide);
      }
    });

  }
  List() {
    this.IsShowList = true;
  }
  Clear() {
    this.IsShowList = true;
  }

  Save() {
    this.loanSanctionDetails.forEach(a => { a.id = 0 });
    var model: LoanSanctionModel =
    {
      loanRequestId: Number(this.ReqId),
      loanTypeID: Number(this.loanTypeId),
      pacsId: 1,
      fYearId: 1,
      sanctionNo: 0,
      sanctionDate: new Date(),
      memberID: Number(this.memberId),
      sanctionAmount: this.SanctionAmount,
      loanSanctionDetails: this.loanSanctionDetails,
      id: 0
    }
    this._apiService.SaveLoanSanction(model).subscribe((result: any) => {
      if (result) {
        alert('success')
      }
      else {
        alert('failed to save')
      }
    });

  }

  selectedRequest(e: any) {
    this.loanSanctionDetails = [];
    let id: number = e.target.value;
    this._apiService.GetRequestById(id).subscribe((result: any) => {
      this.model = result;
      this.loanSanctionDetails = this.model.loanSanctionDetails;
      this.SanctionAmount = 0;
      this.loanTypeId = result.loanTypeID;
      for (let i = 0; i < this.loanSanctionDetails.length; i++) {
        this.SanctionAmount = Number(this.SanctionAmount) + Number(this.loanSanctionDetails[i].cash) +
          Number(this.loanSanctionDetails[i].seed) + Number(this.loanSanctionDetails[i].fertilizer) +
          Number(this.loanSanctionDetails[i].pesticide) + Number(this.loanSanctionDetails[i].kindSeed) + Number(this.loanSanctionDetails[i].kindFertilizer) + Number(this.loanSanctionDetails[i].kindPesticide);
      }

    });

  }
  selected(e: any) {
    let id: number = e.target.value;
    this.memberId = id.toString();
    this.GetRequesNos();
    this._apiService.GetMemberInfo(id).subscribe((result: any) => {
      this.memberName = result.name;
      this.memberAdd1 = result.address1;
      this.memberAdd2 = result.address2;
      this.memberAdd3 = result.address3;
      this.mobile = result.mobileNumber;
      this.photoUrl = result.photoUrl;
      this.aadhar=result.adhaarNumber;;
    });

  }
  GetRequesNos() {
    this._apiService.GetRequestNos(1, Number(this.memberId)).subscribe((result: ComboModel[]) => {
      this.loanTypList = result;
      console.log(this.loanTypList);
    });
  }
  GetMemberList() {
    this._apiService.BindMember(1).subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }

}
