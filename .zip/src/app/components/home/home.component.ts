import { Component, OnInit, ViewChild, AfterContentInit } from '@angular/core';
import { FormGroup, RequiredValidator } from '@angular/forms'
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanRequestModel } from 'src/app/model/LoanRequestModel';
import { CropDetails } from 'src/app/model/CropDetails';
import { SuretyDetails } from 'src/app/model/SuretyDetails';
import { JLGTypeModel } from 'src/app/model/JLGTypeModel';
import { JLGLoanMemberModel } from 'src/app/model/JLGLoanMemberModel';
import { TieupModel } from 'src/app/model/TieupModel';
import { JewelDetails } from 'src/app/model/JewelDetails';
import { LandTypeModel } from 'src/app/model/LandTypeModel';

declare var $: any;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  loanTypList: ComboModel[] = [];
  memberId: number = 0;
  loanType: string = '';
  suretyDetails: SuretyDetails[] = [];;
  loanTypeId: number = 0;
  cropDetails: CropDetails[] = [];
  JLGDetails: JLGTypeModel[] = [];
  JLGMembers: JLGLoanMemberModel[] = [];
  TieupDetails: TieupModel[] = [];
  JewelDetails: JewelDetails[] = [];
  LandPledgeDetails: LandTypeModel[] = [];
  IsShowList: boolean = false;
  Adangal: boolean = false;
  PasaliYear: number = 0;
  LoanReqModel=new FormGroup({});

  constructor(private _apiService: APICall) { }

  ngOnInit() {
    this.GetLoanTypes();
  }
  List() {
    this.IsShowList = true;
  }
  Clear() {
    this.memberId = 0;
    this.loanTypeId = 0;
  }
  GetLoanTypes() {
    this._apiService.BindLoanType().subscribe((result: ComboModel[]) => {
      this.loanTypList = result;
      console.log(this.loanTypList);
    });
  }
  selected(e: any) {
    this.loanType = e.target.value;
    this.loanTypeId = $(e.target).find('option:selected').data('type');
  }
  setJewelDetails(e: any) {
    this.JewelDetails = e;
  }
  setLandDetails(e: any) {
    this.LandPledgeDetails = e;
  }
  setTieupDetails(e: any) {
    this.TieupDetails = e;
  }
  surveydetailsInvoke(e: any) {
    this.memberId = e;
  }
  setSuretyDetails(e: any) {
    this.suretyDetails = e;
  }
  setCropDetails(e: any) {
    this.cropDetails = e;
  }
  setJLGDetails(e: any) {
    this.JLGDetails = e;
  }
  setJLGMember(e: any) {
    this.JLGMembers = e;
  }
  setLoanType(e: any) {
    this.loanType = e;
  }
  setLoanTypeId(e: any) {
    this.loanTypeId = e;
  }
  setAdangal(e: any) {
    this.Adangal = e;
  }
  setPasali(e: any) {
    this.PasaliYear = e;
  }
  Save() {
    debugger;
    let model: LoanRequestModel =
    {
      createdDate: new Date(),
      fYearId: 1,
      loanTypeID: this.loanTypeId,
      memberID: this.memberId,
      pacsId: 1,
      requestDate: new Date(),
      requestNo: 0,
      isAdangal: this.Adangal,
      pasalaiYear: this.PasaliYear,
      loanRequestDetails: this.cropDetails,
      vaoCertificateHeaderId: 4,
      suretyDetails: this.suretyDetails,
      jlgLoanTypeDetails: this.JLGDetails,
      jlgLoanMemberDetails: this.JLGMembers,
      tieUpCompanyDetails: this.TieupDetails,
      jewelPledgedDetails: this.JewelDetails,
      landPledgedDetails: this.LandPledgeDetails
    };
    this._apiService.SaveLoanRequest(model).subscribe((result: boolean) => {
      if (result) {
        alert('success')
      }
      else {
        alert('failed to save')
      }
    });
  }
}
