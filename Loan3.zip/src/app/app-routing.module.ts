import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { AdministrationComponent } from './components/administration/administration.component';
import { LoanSanctionComponent } from './components/loan-sanction/loan-sanction.component';
import { LoanIssueComponent } from './components/loan-issue/loan-issue.component';
const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'administration', component: AdministrationComponent },
  { path: 'loan-sanction', component: LoanSanctionComponent },
  { path: 'loan-issue', component: LoanIssueComponent }

];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponent = [HomeComponent]
