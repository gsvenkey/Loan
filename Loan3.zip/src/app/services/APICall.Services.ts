import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanRequestModel } from 'src/app/model/LoanRequestModel';
import { LoanListModel } from 'src/app/model/LoanListModel';
import { LoanSanctionListModel } from 'src/app/model/LoanSanctionListModel'
import { LoanIssueListModel } from 'src/app/model/LoanIssueListModel'
import { TieupCompanyModel } from 'src/app/model/TieupCompanyModel'
import { LoanSanctionModel, LoanSanctionDetails } from '../model/LoanSanctionModel';

@Injectable({
  providedIn: 'root'
})
export class APICall {
  constructor(private httpClient: HttpClient) {
  }
  baseUrl: string = "https://localhost:44367/api/";
  BindJewelList() {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'JewelMaster/SelectJewel');
  }
  BindSubRegDistrict(pacsId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'SubRegisterOffice/SelectSubRegsterDistrict/' + pacsId);
  }
  GetLoanRatioForCrop(pacsId: number, cropId: number, acre: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<LoanSanctionDetails>(this.baseUrl + 'LoanRatioMaster/GetLoanRatioForCrop/' + pacsId + "/" + cropId + "/" + acre);
  }

  GetLoanEstimationAmount(pacsId: number, cropId: number, acre: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<number>(this.baseUrl + 'LoanRatioMaster/GetEstimationAmount/' + pacsId + "/" + cropId + "/" + acre);
  }

  BindSubRegOffice(districtId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'SubRegisterOffice/SelectSubRegsterOffice/' + districtId);
  }
  BindTieupCompanyList(pacsId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'TieUpCompanyMaster/SelectCompany/' + pacsId);
  }
  GetTieupCompanyDetailsById(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<TieupCompanyModel>(this.baseUrl + 'TieUpCompanyMaster/GetCompanyDetails/' + id);
  }
  BindMember(pacsId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'MemberMaster/SelectMember/' + pacsId);
  }
  BindJlgMember(pacsId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'MemberMaster/SelectJlgMember/' + pacsId);
  }
  GetRequestNos(pacsId: number, memberId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'LoanRequest/SelectRequestNo/' + pacsId + "/" + memberId);
  }
  GetRequestById(reqId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'LoanSanction/GetLoanRequestDetail/' + reqId);
  }
  GetLoanIssueDetailsById(reqId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<any[]>(this.baseUrl + 'LoanIssue/GetLoanSanctionDetail/' + reqId);
  }
  SaveLoanSanction(model: LoanSanctionModel) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.post<boolean>(this.baseUrl + 'LoanSanction', model);
  }
  SaveLoanIssue(model: LoanSanctionModel) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.post<boolean>(this.baseUrl + 'LoanIssue', model);
  }
  GetCropPeriod(pacsId: number, cropId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<number>(this.baseUrl + 'CropMaster/getCropPeriod/' + pacsId + "/" + cropId);
  }
  BindLoanType() {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'LoanTypeMaster/SelectLoanType');
  }
  BindLoanList(pacsId: number, fyearId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<LoanListModel[]>(this.baseUrl + 'LoanRequest/GetList/' + pacsId + "/" + fyearId);
  }
  BindLoanSanctionList(pacsId: number, fyearId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<LoanSanctionListModel[]>(this.baseUrl + 'LoanSanction/GetList/' + pacsId + "/" + fyearId);
  }
  GetLoanSanctionDetails(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<LoanListModel[]>(this.baseUrl + 'LoanSanction/GetById/' + id);
  }
  DeleteLoanSanctionRequest(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.delete<boolean>(this.baseUrl + 'LoanSanction/' + id);
  }
  BindLoanIssueList(pacsId: number, fyearId: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<LoanIssueListModel[]>(this.baseUrl + 'LoanIssue/GetList/' + pacsId + "/" + fyearId);
  }
  GetLoanIssueDetails(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<LoanListModel[]>(this.baseUrl + 'LoanIssue/GetById/' + id);
  }
  DeleteLoanIssueRequest(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.delete<boolean>(this.baseUrl + 'LoanIssue/' + id);
  }
  GetLoanDetails(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<LoanRequestModel>(this.baseUrl + 'LoanRequest/GetById/' + id);
  }
  DeleteLoanRequest(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.delete<boolean>(this.baseUrl + 'LoanRequest/' + id);
  }
  UpdateLoanRequest(id: number, model: LoanRequestModel) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.put<boolean>(this.baseUrl + 'LoanRequest/' + id, model);
  }
  BindCropCategoryList() {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'CropCategory/SelectCropCategory');
  }
  BindCropListByCategory(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'CropMaster/SelectCrop/' + id);
  }
  GetMemberInfo(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'MemberMaster/GetMemberInfo/' + id);
  }
  GetSurveyDetails(id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'VAOCertificate/GetServeyDetails/' + id);
  }

  GetSanctionNoList(pacsId: number,id: number) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.get<ComboModel[]>(this.baseUrl + 'LoanSanction/SelectSanctionNo/' + pacsId + "/" + id);
  }
  SaveLoanRequest(model: LoanRequestModel) {
    let headers = new HttpHeaders();
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Access-Control-Allow-Origin', 'http://localhost:4200');
    headers.append('Accept', 'application/json, text/plain, */*');
    const httpOptions = { headers: headers };
    return this.httpClient.post<boolean>(this.baseUrl + 'LoanRequest', model, httpOptions);
  }
}
