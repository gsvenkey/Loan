import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { APICall } from 'src/app/services/APICall.Services';
import { ComboModel } from 'src/app/model/ComboModel';
import { LoanIssueDetails } from 'src/app/model/LoanIssueModel';

@Component({
  selector: 'app-loan-issue',
  templateUrl: './loan-issue.component.html',
  styleUrls: ['./loan-issue.component.css']
})
export class LoanIssueComponent implements OnInit {

  loanTypList: ComboModel[] = [];
  sanctionNoList: ComboModel[] = [];
  memberList: ComboModel[] = [];
  memberName: string = "";
  memberAdd1: string = "";
  memberAdd2: string = "";
  memberAdd3: string = "";
  mobile: string = "";
  photoUrl: string = "";
  IsShowList: boolean = false;
  SanctionDate: String = new Date().toDateString();
  loanIssueDetails: LoanIssueDetails[] = [];

  constructor(private _apiService: APICall) { }

  ngOnInit() {
    this.GetMemberList();
    //this.GetSanctionNoList();
  }
  List() {
    this.IsShowList = true;
  }
  Clear() {
    this.IsShowList = true;
  }
  Save() {
    this.IsShowList = true;
  }
  selected(e: any) {
    let id: number = e.target.value;
    this._apiService.GetMemberInfo(id).subscribe((result: any) => {
      this.memberName = result.name;
      this.memberAdd1 = result.address1;
      this.memberAdd2 = result.address2;
      this.memberAdd3 = result.address3;
      this.mobile = result.mobileNumber;
      this.photoUrl = result.photoUrl;
    });
    this.GetSanctionNoList(id);
  }
  // GetLoanTypes()
  // {
  //   this._apiService.BindLoanType().subscribe((result:ComboModel[]) => {
  //     this.loanTypList=result;
  //     console.log(this.loanTypList);
  //   });
  // }
  GetSanctionNoList(id: number) {
    this._apiService.GetSanctionNoList(1, id).subscribe((result: ComboModel[]) => {
      this.sanctionNoList = result;
      console.log(this.loanTypList);
    });
  }
  GetMemberList() {
    this._apiService.BindMember(1).subscribe((result: ComboModel[]) => {
      this.memberList = result;
      console.log(this.memberList);
    });
  }

  selectedSanction(e: any) {
    this.loanIssueDetails = [];
    let id: number = e.target.value;
    this._apiService.GetLoanIssueDetailsById(id).subscribe((result: any) => {
      this.loanIssueDetails = result;
    });
  }

}
