export class TieupCompanyModel
{
  companyName: string=''
  companyAddress: string=''
  contactNo: number=0
  
    constructor()
    {

    }
}