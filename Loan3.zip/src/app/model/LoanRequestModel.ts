import {CropDetails} from  'src/app/model/CropDetails';
import {SuretyDetails} from  'src/app/model/SuretyDetails';
import {JLGTypeModel} from  'src/app/model/JLGTypeModel';
import {JLGLoanMemberModel} from  'src/app/model/JLGLoanMemberModel';
import {TieupModel} from  'src/app/model/TieupModel';
import {JewelDetails} from  'src/app/model/JewelDetails';
import {LandTypeModel} from  'src/app/model/LandTypeModel';



export class LoanRequestModel
{
    createdDate: Date = new Date()
    requestNo: number =0
    pacsId: number =0
    fYearId: number =0
    requestDate: Date = new Date()
    loanTypeID: number =0
    //vaoCertificateHeaderId: number =0
    memberID: number =0
    isAdangal:boolean=false
    pasalaiYear:number=0
    loanRequestDetails: CropDetails[] = []
    suretyDetails: SuretyDetails[]=[]
    jlgLoanTypeDetails:JLGTypeModel[]=[]
    jlgLoanMemberDetails:JLGLoanMemberModel[]=[]
    tieUpCompanyDetails:TieupModel[]=[]
    jewelPledgedDetails:JewelDetails[]=[]
    landPledgedDetails:LandTypeModel[]=[]
  }
