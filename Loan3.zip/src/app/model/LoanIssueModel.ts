export class LoanIssueDetails
{
    sanctionId: number=0
    cropId: number=0
    vaoDetailId: number=0
    loanDuePeriod: number=0
    cultivationAcre: number=0
    sanctionAcre: number=0
    cash: number=0
    seed: number=0
    fertilizer: number=0
    pesticide: number=0
    acreCash:number=0
    kindFertilizer: number=0
    kindSeed: number=0
    kindPesticide: number=0
    maintanance: number=0
    vaoDetail: string=''
    id: number=0
    createdDate: string=''
    modifiedDate: string=''
    isDeleted: boolean=false
    createdBy: string=''
    modifiedBy: string=''
    message: string=''
    constructor()
    {

    }
}
