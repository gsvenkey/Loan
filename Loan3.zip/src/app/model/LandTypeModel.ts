export class LandTypeModel
{
    id: number = 0
    createdDate: Date = new Date()
    modifiedDate: Date = new Date()
    isDeleted: boolean = false
    createdBy: number = 0
    modifiedBy: number = 0
    message: string =''
    loanRequestId: number = 0
    subRegisterId: number = 0
    mortgageRegNo: string =''
    dateOfMortgage: Date = new Date()
    mortgageAmount: number = 0
    constructor()
    {

    }
}