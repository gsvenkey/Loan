export class CropDetails{
category:string="";
crop:string="";
cropId:number=0;
surveyNo:string="";
acre:number=0;
loanDuePeriod:number=0;
cultivationAcre:number=0;
requestAmount:number=0;
duePeriod:number=0;
estimateAmount:number=0;
    constructor()
    {

    }
}